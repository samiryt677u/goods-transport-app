<?php
/**
 * Shared helper functions used across every API endpoint.
 */

/**
 * Send a standard JSON response and terminate the script.
 */
function sendResponse(bool $status, string $message, mixed $data = null, int $httpCode = 200): never
{
    http_response_code($httpCode);
    $response = ['status' => $status, 'message' => $message];
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response, JSON_UNESCAPED_SLASHES);
    exit();
}

/**
 * Recursively strip tags and trim strings. Used on every incoming field.
 * (Prepared statements handle SQL injection; this guards against stored XSS.)
 */
function sanitizeInput(mixed $data): mixed
{
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    if (is_string($data)) {
        return trim(strip_tags($data));
    }
    return $data;
}

/**
 * Read + decode JSON request body into a sanitized associative array.
 */
function getJsonInput(): array
{
    $raw = file_get_contents('php://input');
    if (empty($raw)) {
        return [];
    }
    $input = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($input)) {
        sendResponse(false, 'Invalid JSON payload', null, 400);
    }
    return sanitizeInput($input);
}

/**
 * Checks required fields exist and are non-empty.
 * Returns an array of missing field names (empty array = all present).
 */
function validateRequired(array $data, array $fields): array
{
    $missing = [];
    foreach ($fields as $field) {
        if (!array_key_exists($field, $data) || trim((string) $data[$field]) === '') {
            $missing[] = $field;
        }
    }
    return $missing;
}

/**
 * Reject the request early if it doesn't use the expected HTTP method.
 */
function requireMethod(string $method): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== $method) {
        sendResponse(false, "This endpoint only accepts $method requests", null, 405);
    }
}

/**
 * Indian 10-digit mobile number starting 6-9.
 */
function validateMobile(string $mobile): bool
{
    return (bool) preg_match('/^[6-9]\d{9}$/', $mobile);
}

function validateEmail(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Unique, human-readable booking reference, e.g. GT2608054F3A9
 */
function generateBookingCode(): string
{
    return 'GT' . date('ymd') . strtoupper(substr(bin2hex(random_bytes(4)), 0, 5));
}

/**
 * Haversine formula: straight-line distance in km between two lat/lng points.
 * Used as a lightweight fare estimator (no Google Distance Matrix billing needed).
 */
function calculateDistanceKm(float $lat1, float $lng1, float $lat2, float $lng2): float
{
    $earthRadiusKm = 6371;

    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);

    $a = sin($dLat / 2) ** 2
        + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

    return round($earthRadiusKm * $c, 2);
}
