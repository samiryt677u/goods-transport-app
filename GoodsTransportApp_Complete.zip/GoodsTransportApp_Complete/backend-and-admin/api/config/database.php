<?php
/**
 * Database Connection (PDO Singleton)
 * ------------------------------------
 * Edit the four values below to match your cPanel MySQL database
 * before uploading. Do NOT commit real credentials to public repos.
 */
class Database
{
    private static ?Database $instance = null;
    private PDO $conn;

    // ---- demo.mytoolshub.co.in (cPanel) ----
    private string $host     = 'localhost';
    private string $db_name  = 'mytoolsh_demodatabase';
    private string $username = 'mytoolsh_demouser';
    private string $password = 'Samir@154198';
    // -----------------------------------------

    private function __construct()
    {
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->db_name};charset=utf8mb4";
            $this->conn = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+05:30'",
            ]);
        } catch (PDOException $e) {
            error_log('DB Connection Error: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode([
                'status'  => false,
                'message' => 'Database connection failed. Please try again later.',
            ]);
            exit();
        }
    }

    public static function getInstance(): Database
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection(): PDO
    {
        return $this->conn;
    }

    // Prevent cloning and unserialization of the singleton instance
    private function __clone() {}
    public function __wakeup()
    {
        throw new Exception('Cannot unserialize a singleton.');
    }
}
