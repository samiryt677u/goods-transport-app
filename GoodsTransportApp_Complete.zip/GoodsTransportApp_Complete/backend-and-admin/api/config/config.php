<?php
/**
 * Global API Configuration
 * Loaded first by every API endpoint.
 */

// ---- Error handling: log everything, show nothing to the client ----
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

date_default_timezone_set('Asia/Kolkata');

// ---- JWT settings ----
// IMPORTANT: change JWT_SECRET to a long random string before going live.
// Generate one with: php -r "echo bin2hex(random_bytes(32));"
define('JWT_SECRET', '62446a8c2e63560ac206af94da37d20a2370c80866ef41e5df99fd0648680d62');
define('JWT_ISSUER', 'goods-transport-api');
define('JWT_EXPIRY_SECONDS', 60 * 60 * 24 * 30); // 30 days

// ---- CORS + JSON headers (Flutter app calls this API from a different origin) ----
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Preflight requests end here
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ---- Polyfill: getallheaders() is Apache-only; some hosts run PHP-FPM ----
if (!function_exists('getallheaders')) {
    function getallheaders(): array
    {
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (str_starts_with($name, 'HTTP_')) {
                $headerName = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))));
                $headers[$headerName] = $value;
            } elseif ($name === 'CONTENT_TYPE') {
                $headers['Content-Type'] = $value;
            } elseif ($name === 'CONTENT_LENGTH') {
                $headers['Content-Length'] = $value;
            }
        }
        return $headers;
    }
}

// ---- Custom exception -> JSON so a stray error never leaks HTML to the app ----
set_exception_handler(function (Throwable $e) {
    error_log('Uncaught Exception: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    echo json_encode([
        'status'  => false,
        'message' => 'Something went wrong. Please try again.',
    ]);
    exit();
});
