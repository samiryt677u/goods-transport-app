<?php
/**
 * POST /api/payments/update.php
 * Header: Authorization: Bearer <token>   (customer or driver)
 *
 * Body: { "booking_id", "payment_status": "paid" | "failed", "transaction_id"? }
 *
 * - Cash payments: only the driver assigned to the booking can mark
 *   them paid (they physically collected the cash on delivery).
 * - Online payments: only the customer who booked it can confirm
 *   paid/failed (after completing checkout with the payment gateway).
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../middleware/auth_middleware.php';

requireMethod('POST');

$authUser = authenticateRequest();
$input    = getJsonInput();

$missing = validateRequired($input, ['booking_id', 'payment_status']);
if (!empty($missing)) {
    sendResponse(false, 'Missing required fields: ' . implode(', ', $missing), null, 400);
}

$bookingId     = (int) $input['booking_id'];
$paymentStatus = strtolower($input['payment_status']);
$transactionId = $input['transaction_id'] ?? null;

if (!in_array($paymentStatus, ['paid', 'failed'], true)) {
    sendResponse(false, 'payment_status must be either paid or failed', null, 400);
}

$pdo = Database::getInstance()->getConnection();

try {
    $stmt = $pdo->prepare(
        'SELECT b.customer_id, b.driver_id, p.id AS payment_id, p.payment_mode, p.payment_status AS current_status
         FROM bookings b
         JOIN payments p ON p.booking_id = b.id
         WHERE b.id = :id LIMIT 1'
    );
    $stmt->execute(['id' => $bookingId]);
    $row = $stmt->fetch();

    if (!$row) {
        sendResponse(false, 'Booking or payment record not found', null, 404);
    }

    if ($row['current_status'] === 'paid') {
        sendResponse(false, 'This payment has already been marked as paid', null, 409);
    }

    // ---- Authorization: cash -> driver, online -> customer ----
    if ($row['payment_mode'] === 'cash') {
        if ($authUser['role'] !== 'driver' || (int) $row['driver_id'] !== (int) $authUser['user_id']) {
            sendResponse(false, 'Only the assigned driver can confirm a cash payment', null, 403);
        }
    } else { // online
        if ($authUser['role'] !== 'customer' || (int) $row['customer_id'] !== (int) $authUser['user_id']) {
            sendResponse(false, 'Only the customer can confirm an online payment', null, 403);
        }
    }

    $stmt = $pdo->prepare(
        'UPDATE payments
         SET payment_status = :status, transaction_id = :transaction_id,
             paid_at = CASE WHEN :status2 = "paid" THEN NOW() ELSE paid_at END
         WHERE id = :payment_id'
    );
    $stmt->execute([
        'status'         => $paymentStatus,
        'status2'        => $paymentStatus,
        'transaction_id' => $transactionId,
        'payment_id'     => $row['payment_id'],
    ]);

    sendResponse(true, 'Payment status updated successfully', [
        'booking_id'     => $bookingId,
        'payment_status' => $paymentStatus,
    ]);

} catch (PDOException $e) {
    error_log('Payment update error: ' . $e->getMessage());
    sendResponse(false, 'Could not update payment status', null, 500);
}
