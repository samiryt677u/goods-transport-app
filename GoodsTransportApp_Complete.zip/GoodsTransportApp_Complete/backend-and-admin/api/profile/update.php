<?php
/**
 * POST /api/profile/update.php
 * Header: Authorization: Bearer <token>
 *
 * Body (all fields optional, send only what changed):
 *   {
 *     "name", "email",
 *     "vehicle_number", "driving_license",      // driver only
 *     "is_available": true|false,               // driver online/offline toggle
 *     "current_password", "new_password"        // to change password
 *   }
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../middleware/auth_middleware.php';

requireMethod('POST');

$authUser = authenticateRequest();
$input    = getJsonInput();

$pdo = Database::getInstance()->getConnection();

try {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => $authUser['user_id']]);
    $currentUser = $stmt->fetch();

    if (!$currentUser) {
        sendResponse(false, 'User not found', null, 404);
    }

    $fields = [];
    $params = ['id' => $authUser['user_id']];

    // ---- Name ----
    if (isset($input['name']) && trim($input['name']) !== '') {
        $fields[]      = 'name = :name';
        $params['name'] = $input['name'];
    }

    // ---- Email ----
    if (isset($input['email'])) {
        if ($input['email'] !== '' && !validateEmail($input['email'])) {
            sendResponse(false, 'Enter a valid email address', null, 400);
        }
        $fields[]       = 'email = :email';
        $params['email'] = $input['email'] ?: null;
    }

    // ---- Driver-only fields ----
    if ($currentUser['role'] === 'driver') {
        if (isset($input['vehicle_number']) && trim($input['vehicle_number']) !== '') {
            $fields[]                 = 'vehicle_number = :vehicle_number';
            $params['vehicle_number'] = $input['vehicle_number'];
        }
        if (isset($input['driving_license'])) {
            $fields[]                  = 'driving_license = :driving_license';
            $params['driving_license'] = $input['driving_license'] ?: null;
        }
        if (isset($input['is_available'])) {
            $fields[]                = 'is_available = :is_available';
            $params['is_available']  = $input['is_available'] ? 1 : 0;
        }
    }

    // ---- Password change ----
    if (!empty($input['new_password'])) {
        if (empty($input['current_password'])) {
            sendResponse(false, 'current_password is required to set a new password', null, 400);
        }
        if (!password_verify($input['current_password'], $currentUser['password'])) {
            sendResponse(false, 'Current password is incorrect', null, 401);
        }
        if (strlen($input['new_password']) < 6) {
            sendResponse(false, 'New password must be at least 6 characters', null, 400);
        }
        $fields[]           = 'password = :password';
        $params['password'] = password_hash($input['new_password'], PASSWORD_DEFAULT);
    }

    if (empty($fields)) {
        sendResponse(false, 'No valid fields provided to update', null, 400);
    }

    $sql  = 'UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    // ---- Return fresh profile ----
    $stmt = $pdo->prepare(
        'SELECT u.id, u.name, u.mobile, u.email, u.role, u.profile_image,
                u.vehicle_category_id, u.vehicle_number, u.driving_license,
                u.is_available, u.status, u.created_at,
                vc.name AS vehicle_category_name
         FROM users u
         LEFT JOIN vehicle_categories vc ON vc.id = u.vehicle_category_id
         WHERE u.id = :id LIMIT 1'
    );
    $stmt->execute(['id' => $authUser['user_id']]);
    $profile = $stmt->fetch();
    $profile['id'] = (int) $profile['id'];
    $profile['is_available'] = (bool) $profile['is_available'];

    sendResponse(true, 'Profile updated successfully', $profile);

} catch (PDOException $e) {
    error_log('Profile update error: ' . $e->getMessage());
    sendResponse(false, 'Could not update profile', null, 500);
}
