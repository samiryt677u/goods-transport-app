<?php
/**
 * GET /api/profile/get.php
 * Header: Authorization: Bearer <token>
 *
 * Returns the logged-in user's full profile (customer or driver).
 * For drivers, includes their vehicle category details via JOIN.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../middleware/auth_middleware.php';

requireMethod('GET');

$authUser = authenticateRequest();
$pdo = Database::getInstance()->getConnection();

try {
    $stmt = $pdo->prepare(
        'SELECT u.id, u.name, u.mobile, u.email, u.role, u.profile_image,
                u.vehicle_category_id, u.vehicle_number, u.driving_license,
                u.is_available, u.status, u.created_at,
                vc.name AS vehicle_category_name
         FROM users u
         LEFT JOIN vehicle_categories vc ON vc.id = u.vehicle_category_id
         WHERE u.id = :id LIMIT 1'
    );
    $stmt->execute(['id' => $authUser['user_id']]);
    $profile = $stmt->fetch();

    if (!$profile) {
        sendResponse(false, 'User not found', null, 404);
    }

    $profile['id'] = (int) $profile['id'];
    $profile['is_available'] = (bool) $profile['is_available'];
    if ($profile['vehicle_category_id'] !== null) {
        $profile['vehicle_category_id'] = (int) $profile['vehicle_category_id'];
    }

    sendResponse(true, 'Profile fetched successfully', $profile);

} catch (PDOException $e) {
    error_log('Profile get error: ' . $e->getMessage());
    sendResponse(false, 'Could not fetch profile', null, 500);
}
