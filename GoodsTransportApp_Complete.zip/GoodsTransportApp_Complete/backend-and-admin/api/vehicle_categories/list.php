<?php
/**
 * GET /api/vehicle_categories/list.php
 *
 * Public endpoint (no auth) — used on the customer's "Select Vehicle
 * Category" screen. Returns only active categories, cheapest first.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/functions.php';

requireMethod('GET');

$pdo = Database::getInstance()->getConnection();

try {
    $stmt = $pdo->query(
        "SELECT id, name, icon, base_fare, per_km_rate, capacity
         FROM vehicle_categories
         WHERE status = 'active'
         ORDER BY sort_order ASC, base_fare ASC"
    );
    $categories = $stmt->fetchAll();

    foreach ($categories as &$c) {
        $c['id']          = (int) $c['id'];
        $c['base_fare']   = (float) $c['base_fare'];
        $c['per_km_rate'] = (float) $c['per_km_rate'];
    }
    unset($c);

    sendResponse(true, 'Vehicle categories fetched successfully', $categories);

} catch (PDOException $e) {
    error_log('Vehicle categories list error: ' . $e->getMessage());
    sendResponse(false, 'Could not fetch vehicle categories', null, 500);
}
