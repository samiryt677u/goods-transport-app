<?php
/**
 * Auth Middleware
 * ----------------
 * Include this file (after config.php/jwt.php/functions.php are loaded)
 * on every endpoint that requires a logged-in user, then call:
 *
 *      $user = authenticateRequest();          // any logged-in user
 *      requireRole($user, 'driver');           // driver-only endpoints
 */

function authenticateRequest(): array
{
    $headers = getallheaders();

    // Header names can arrive with different casing depending on the server
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    if (empty($authHeader) || !preg_match('/^Bearer\s+(\S+)$/i', $authHeader, $matches)) {
        sendResponse(false, 'Authorization token missing', null, 401);
    }

    $payload = JWT::decode($matches[1]);

    if ($payload === false) {
        sendResponse(false, 'Invalid or expired token. Please login again.', null, 401);
    }

    if (!isset($payload['user_id'], $payload['role'])) {
        sendResponse(false, 'Malformed token payload', null, 401);
    }

    return $payload; // ['user_id' => .., 'role' => .., 'mobile' => .., 'name' => ..]
}

function requireRole(array $authPayload, string $requiredRole): void
{
    if ($authPayload['role'] !== $requiredRole) {
        sendResponse(false, "This action requires a $requiredRole account", null, 403);
    }
}
