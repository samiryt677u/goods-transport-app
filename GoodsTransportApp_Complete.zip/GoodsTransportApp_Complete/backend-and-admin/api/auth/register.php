<?php
/**
 * POST /api/auth/register.php
 *
 * Body (customer):
 *   { "name", "mobile", "password", "role": "customer", "email"? }
 *
 * Body (driver):
 *   { "name", "mobile", "password", "role": "driver",
 *     "vehicle_category_id", "vehicle_number", "driving_license"?, "email"? }
 *
 * Response: user object + JWT token
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';

requireMethod('POST');

$input = getJsonInput();

// ---- Base validation ----
$missing = validateRequired($input, ['name', 'mobile', 'password', 'role']);
if (!empty($missing)) {
    sendResponse(false, 'Missing required fields: ' . implode(', ', $missing), null, 400);
}

$name     = $input['name'];
$mobile   = $input['mobile'];
$password = $input['password'];
$role     = strtolower($input['role']);
$email    = $input['email'] ?? null;

if (!validateMobile($mobile)) {
    sendResponse(false, 'Enter a valid 10-digit Indian mobile number', null, 400);
}

if (!in_array($role, ['customer', 'driver'], true)) {
    sendResponse(false, 'Role must be either customer or driver', null, 400);
}

if (strlen($password) < 6) {
    sendResponse(false, 'Password must be at least 6 characters', null, 400);
}

if ($email !== null && $email !== '' && !validateEmail($email)) {
    sendResponse(false, 'Enter a valid email address', null, 400);
}

// ---- Driver-only fields ----
$vehicleCategoryId = null;
$vehicleNumber     = null;
$drivingLicense    = null;

if ($role === 'driver') {
    $driverMissing = validateRequired($input, ['vehicle_category_id', 'vehicle_number']);
    if (!empty($driverMissing)) {
        sendResponse(false, 'Driver signup requires: ' . implode(', ', $driverMissing), null, 400);
    }
    $vehicleCategoryId = (int) $input['vehicle_category_id'];
    $vehicleNumber     = $input['vehicle_number'];
    $drivingLicense    = $input['driving_license'] ?? null;
}

$pdo = Database::getInstance()->getConnection();

try {
    // ---- Uniqueness check ----
    $stmt = $pdo->prepare('SELECT id FROM users WHERE mobile = :mobile LIMIT 1');
    $stmt->execute(['mobile' => $mobile]);
    if ($stmt->fetch()) {
        sendResponse(false, 'This mobile number is already registered', null, 409);
    }

    // ---- Vehicle category must exist & be active for drivers ----
    if ($role === 'driver') {
        $stmt = $pdo->prepare('SELECT id FROM vehicle_categories WHERE id = :id AND status = "active" LIMIT 1');
        $stmt->execute(['id' => $vehicleCategoryId]);
        if (!$stmt->fetch()) {
            sendResponse(false, 'Selected vehicle category is invalid or inactive', null, 400);
        }
    }

    // ---- Insert ----
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare(
        'INSERT INTO users (name, mobile, email, password, role, vehicle_category_id, vehicle_number, driving_license)
         VALUES (:name, :mobile, :email, :password, :role, :vehicle_category_id, :vehicle_number, :driving_license)'
    );
    $stmt->execute([
        'name'                => $name,
        'mobile'              => $mobile,
        'email'               => $email ?: null,
        'password'            => $passwordHash,
        'role'                => $role,
        'vehicle_category_id' => $vehicleCategoryId,
        'vehicle_number'      => $vehicleNumber,
        'driving_license'     => $drivingLicense,
    ]);

    $userId = (int) $pdo->lastInsertId();

    $token = JWT::encode([
        'user_id' => $userId,
        'role'    => $role,
        'mobile'  => $mobile,
        'name'    => $name,
    ]);

    sendResponse(true, 'Registration successful', [
        'token' => $token,
        'user'  => [
            'id'                  => $userId,
            'name'                => $name,
            'mobile'              => $mobile,
            'email'               => $email,
            'role'                => $role,
            'vehicle_category_id' => $vehicleCategoryId,
            'vehicle_number'      => $vehicleNumber,
        ],
    ], 201);

} catch (PDOException $e) {
    error_log('Register error: ' . $e->getMessage());
    sendResponse(false, 'Registration failed. Please try again.', null, 500);
}
