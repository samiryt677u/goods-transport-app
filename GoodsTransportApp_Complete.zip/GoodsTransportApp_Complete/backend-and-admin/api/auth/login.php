<?php
/**
 * POST /api/auth/login.php
 *
 * Body: { "mobile", "password", "role": "customer" | "driver" }
 * Response: user object + JWT token
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';

requireMethod('POST');

$input = getJsonInput();

$missing = validateRequired($input, ['mobile', 'password', 'role']);
if (!empty($missing)) {
    sendResponse(false, 'Missing required fields: ' . implode(', ', $missing), null, 400);
}

$mobile   = $input['mobile'];
$password = $input['password'];
$role     = strtolower($input['role']);

if (!in_array($role, ['customer', 'driver'], true)) {
    sendResponse(false, 'Role must be either customer or driver', null, 400);
}

$pdo = Database::getInstance()->getConnection();

try {
    $stmt = $pdo->prepare(
        'SELECT id, name, mobile, email, password, role, profile_image,
                vehicle_category_id, vehicle_number, driving_license,
                is_available, status
         FROM users WHERE mobile = :mobile LIMIT 1'
    );
    $stmt->execute(['mobile' => $mobile]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        sendResponse(false, 'Invalid mobile number or password', null, 401);
    }

    if ($user['status'] !== 'active') {
        sendResponse(false, 'Your account is ' . $user['status'] . '. Please contact support.', null, 403);
    }

    if ($user['role'] !== $role) {
        sendResponse(
            false,
            "This mobile number is registered as a {$user['role']}. Please switch role and try again.",
            null,
            409
        );
    }

    $token = JWT::encode([
        'user_id' => (int) $user['id'],
        'role'    => $user['role'],
        'mobile'  => $user['mobile'],
        'name'    => $user['name'],
    ]);

    unset($user['password']);
    $user['id'] = (int) $user['id'];

    sendResponse(true, 'Login successful', [
        'token' => $token,
        'user'  => $user,
    ]);

} catch (PDOException $e) {
    error_log('Login error: ' . $e->getMessage());
    sendResponse(false, 'Login failed. Please try again.', null, 500);
}
