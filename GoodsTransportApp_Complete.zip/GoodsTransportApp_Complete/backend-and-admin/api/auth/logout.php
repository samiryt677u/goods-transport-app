<?php
/**
 * POST /api/auth/logout.php
 * Header: Authorization: Bearer <token>
 *
 * JWTs are stateless, so there is nothing to invalidate server-side.
 * This endpoint verifies the token is valid, then instructs the app
 * to discard it locally. Kept as a real endpoint (not just a no-op)
 * so future versions can add a token-blacklist table without the
 * Flutter app needing any changes.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../middleware/auth_middleware.php';

requireMethod('POST');

$user = authenticateRequest();

sendResponse(true, 'Logged out successfully');
