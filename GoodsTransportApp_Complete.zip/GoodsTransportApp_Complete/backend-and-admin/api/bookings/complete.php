<?php
/**
 * POST /api/bookings/complete.php
 * Header: Authorization: Bearer <token>   (driver only)
 * Body: { "booking_id", "final_fare"? }
 *
 * Only the driver already assigned to the booking can complete it,
 * and only from status "accepted". final_fare is optional — if
 * omitted, the estimated_fare is used as the final amount.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../middleware/auth_middleware.php';

requireMethod('POST');

$authUser = authenticateRequest();
requireRole($authUser, 'driver');

$input = getJsonInput();
$missing = validateRequired($input, ['booking_id']);
if (!empty($missing)) {
    sendResponse(false, 'booking_id is required', null, 400);
}

$bookingId = (int) $input['booking_id'];
$driverId  = (int) $authUser['user_id'];

if (isset($input['final_fare']) && (!is_numeric($input['final_fare']) || $input['final_fare'] < 0)) {
    sendResponse(false, 'final_fare must be a positive number', null, 400);
}

$pdo = Database::getInstance()->getConnection();

try {
    $checkStmt = $pdo->prepare('SELECT status, driver_id, estimated_fare FROM bookings WHERE id = :id LIMIT 1');
    $checkStmt->execute(['id' => $bookingId]);
    $booking = $checkStmt->fetch();

    if (!$booking) {
        sendResponse(false, 'Booking not found', null, 404);
    }

    if ((int) $booking['driver_id'] !== $driverId) {
        sendResponse(false, 'This booking is not assigned to you', null, 403);
    }

    if ($booking['status'] !== 'accepted') {
        sendResponse(false, 'Only an accepted booking can be marked completed (current status: ' . $booking['status'] . ')', null, 409);
    }

    $finalFare = isset($input['final_fare']) ? round((float) $input['final_fare'], 2) : (float) $booking['estimated_fare'];

    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        'UPDATE bookings
         SET status = "completed", final_fare = :final_fare, completed_at = NOW()
         WHERE id = :id AND driver_id = :driver_id AND status = "accepted"'
    );
    $stmt->execute(['final_fare' => $finalFare, 'id' => $bookingId, 'driver_id' => $driverId]);

    if ($stmt->rowCount() === 0) {
        $pdo->rollBack();
        sendResponse(false, 'Could not complete booking — it may have already been updated', null, 409);
    }

    // Keep the payment amount in sync with the final fare
    $payStmt = $pdo->prepare('UPDATE payments SET amount = :amount WHERE booking_id = :booking_id');
    $payStmt->execute(['amount' => $finalFare, 'booking_id' => $bookingId]);

    $pdo->commit();

    sendResponse(true, 'Booking marked as completed', [
        'booking_id'  => $bookingId,
        'status'      => 'completed',
        'final_fare'  => $finalFare,
    ]);

} catch (PDOException $e) {
    $pdo->rollBack();
    error_log('Complete booking error: ' . $e->getMessage());
    sendResponse(false, 'Could not complete booking. Please try again.', null, 500);
}
