<?php
/**
 * GET /api/bookings/details.php?booking_id=123
 * Header: Authorization: Bearer <token>   (customer or driver)
 *
 * Returns full details for one booking, including GPS coordinates
 * for both ends (used to draw the route on the map screen).
 * Only the customer who created it or the driver assigned to it
 * may view it.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../middleware/auth_middleware.php';

requireMethod('GET');

$authUser = authenticateRequest();

$bookingId = (int) ($_GET['booking_id'] ?? 0);
if ($bookingId <= 0) {
    sendResponse(false, 'booking_id is required', null, 400);
}

$pdo = Database::getInstance()->getConnection();

try {
    $stmt = $pdo->prepare(
        'SELECT b.*, 
                c.name AS customer_name, c.mobile AS customer_mobile,
                d.name AS driver_name, d.mobile AS driver_mobile, d.vehicle_number,
                vc.name AS vehicle_category_name,
                p.payment_mode, p.payment_status, p.amount AS payment_amount
         FROM bookings b
         JOIN users c ON c.id = b.customer_id
         LEFT JOIN users d ON d.id = b.driver_id
         JOIN vehicle_categories vc ON vc.id = b.vehicle_category_id
         LEFT JOIN payments p ON p.booking_id = b.id
         WHERE b.id = :id LIMIT 1'
    );
    $stmt->execute(['id' => $bookingId]);
    $booking = $stmt->fetch();

    if (!$booking) {
        sendResponse(false, 'Booking not found', null, 404);
    }

    $isOwner = ($authUser['role'] === 'customer' && (int) $booking['customer_id'] === (int) $authUser['user_id'])
            || ($authUser['role'] === 'driver' && (int) $booking['driver_id'] === (int) $authUser['user_id']);

    if (!$isOwner) {
        sendResponse(false, 'You do not have access to this booking', null, 403);
    }

    // Type casting for a clean JSON response
    foreach (['id', 'customer_id', 'vehicle_category_id'] as $intField) {
        $booking[$intField] = (int) $booking[$intField];
    }
    $booking['driver_id'] = $booking['driver_id'] !== null ? (int) $booking['driver_id'] : null;
    foreach (['pickup_lat', 'pickup_lng', 'delivery_lat', 'delivery_lng', 'distance_km', 'estimated_fare'] as $floatField) {
        $booking[$floatField] = (float) $booking[$floatField];
    }
    $booking['final_fare']      = $booking['final_fare'] !== null ? (float) $booking['final_fare'] : null;
    $booking['payment_amount']  = $booking['payment_amount'] !== null ? (float) $booking['payment_amount'] : null;

    sendResponse(true, 'Booking details fetched successfully', $booking);

} catch (PDOException $e) {
    error_log('Booking details error: ' . $e->getMessage());
    sendResponse(false, 'Could not fetch booking details', null, 500);
}
