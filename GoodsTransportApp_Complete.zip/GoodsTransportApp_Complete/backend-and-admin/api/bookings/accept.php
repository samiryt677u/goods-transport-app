<?php
/**
 * POST /api/bookings/accept.php
 * Header: Authorization: Bearer <token>   (driver only)
 * Body: { "booking_id" }
 *
 * Uses a single conditional UPDATE (status='pending' AND driver_id IS NULL)
 * so that if two drivers tap "Accept" on the same booking at the same
 * moment, only one UPDATE actually matches a row — the loser gets a
 * clean "already accepted" response instead of a corrupted booking.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../middleware/auth_middleware.php';

requireMethod('POST');

$authUser = authenticateRequest();
requireRole($authUser, 'driver');

$input = getJsonInput();
$missing = validateRequired($input, ['booking_id']);
if (!empty($missing)) {
    sendResponse(false, 'booking_id is required', null, 400);
}

$bookingId = (int) $input['booking_id'];
$driverId  = (int) $authUser['user_id'];

$pdo = Database::getInstance()->getConnection();

try {
    $driverStmt = $pdo->prepare('SELECT vehicle_category_id, is_available FROM users WHERE id = :id LIMIT 1');
    $driverStmt->execute(['id' => $driverId]);
    $driver = $driverStmt->fetch();

    if (!$driver || !$driver['vehicle_category_id']) {
        sendResponse(false, 'Your driver profile has no vehicle category set', null, 400);
    }

    // Confirm the booking exists at all (for a clear error message)
    $checkStmt = $pdo->prepare('SELECT status, driver_id, vehicle_category_id FROM bookings WHERE id = :id LIMIT 1');
    $checkStmt->execute(['id' => $bookingId]);
    $booking = $checkStmt->fetch();

    if (!$booking) {
        sendResponse(false, 'Booking not found', null, 404);
    }

    if ((int) $booking['vehicle_category_id'] !== (int) $driver['vehicle_category_id']) {
        sendResponse(false, 'This booking is not for your vehicle category', null, 403);
    }

    // ---- Atomic accept ----
    $stmt = $pdo->prepare(
        'UPDATE bookings
         SET driver_id = :driver_id, status = "accepted", accepted_at = NOW()
         WHERE id = :id AND status = "pending" AND driver_id IS NULL'
    );
    $stmt->execute(['driver_id' => $driverId, 'id' => $bookingId]);

    if ($stmt->rowCount() === 0) {
        sendResponse(false, 'This booking has already been accepted by another driver', null, 409);
    }

    $result = $pdo->prepare(
        'SELECT b.id, b.booking_code, b.status, b.pickup_address, b.delivery_address,
                b.distance_km, b.estimated_fare, b.accepted_at,
                c.name AS customer_name, c.mobile AS customer_mobile
         FROM bookings b
         JOIN users c ON c.id = b.customer_id
         WHERE b.id = :id'
    );
    $result->execute(['id' => $bookingId]);
    $data = $result->fetch();
    $data['id'] = (int) $data['id'];
    $data['distance_km'] = (float) $data['distance_km'];
    $data['estimated_fare'] = (float) $data['estimated_fare'];

    sendResponse(true, 'Booking accepted successfully', $data);

} catch (PDOException $e) {
    error_log('Accept booking error: ' . $e->getMessage());
    sendResponse(false, 'Could not accept booking. Please try again.', null, 500);
}
