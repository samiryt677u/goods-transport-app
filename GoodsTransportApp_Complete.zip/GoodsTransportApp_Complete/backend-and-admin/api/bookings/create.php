<?php
/**
 * POST /api/bookings/create.php
 * Header: Authorization: Bearer <token>   (customer only)
 *
 * Body:
 *   {
 *     "vehicle_category_id",
 *     "pickup_address", "pickup_lat", "pickup_lng",
 *     "delivery_address", "delivery_lat", "delivery_lng",
 *     "goods_description"?,
 *     "payment_mode": "cash" | "online"
 *   }
 *
 * Fare is calculated server-side (base_fare + distance_km * per_km_rate)
 * using the Haversine formula — never trust a client-supplied fare.
 * A matching `payments` row is created in the same transaction.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../middleware/auth_middleware.php';

requireMethod('POST');

$authUser = authenticateRequest();
requireRole($authUser, 'customer');

$input = getJsonInput();

$required = [
    'vehicle_category_id', 'pickup_address', 'pickup_lat', 'pickup_lng',
    'delivery_address', 'delivery_lat', 'delivery_lng', 'payment_mode',
];
$missing = validateRequired($input, $required);
if (!empty($missing)) {
    sendResponse(false, 'Missing required fields: ' . implode(', ', $missing), null, 400);
}

$vehicleCategoryId = (int) $input['vehicle_category_id'];
$pickupAddress      = $input['pickup_address'];
$pickupLat           = (float) $input['pickup_lat'];
$pickupLng           = (float) $input['pickup_lng'];
$deliveryAddress     = $input['delivery_address'];
$deliveryLat         = (float) $input['delivery_lat'];
$deliveryLng         = (float) $input['delivery_lng'];
$goodsDescription    = $input['goods_description'] ?? null;
$paymentMode         = strtolower($input['payment_mode']);

if (!in_array($paymentMode, ['cash', 'online'], true)) {
    sendResponse(false, 'payment_mode must be either cash or online', null, 400);
}

if ($pickupLat < -90 || $pickupLat > 90 || $deliveryLat < -90 || $deliveryLat > 90
    || $pickupLng < -180 || $pickupLng > 180 || $deliveryLng < -180 || $deliveryLng > 180) {
    sendResponse(false, 'Invalid GPS coordinates', null, 400);
}

$pdo = Database::getInstance()->getConnection();

try {
    $stmt = $pdo->prepare("SELECT * FROM vehicle_categories WHERE id = :id AND status = 'active' LIMIT 1");
    $stmt->execute(['id' => $vehicleCategoryId]);
    $category = $stmt->fetch();

    if (!$category) {
        sendResponse(false, 'Selected vehicle category is invalid or inactive', null, 400);
    }

    $distanceKm = calculateDistanceKm($pickupLat, $pickupLng, $deliveryLat, $deliveryLng);

    if ($distanceKm <= 0) {
        sendResponse(false, 'Pickup and delivery locations must be different', null, 400);
    }

    $estimatedFare = round((float) $category['base_fare'] + ($distanceKm * (float) $category['per_km_rate']), 2);
    $bookingCode   = generateBookingCode();

    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        'INSERT INTO bookings
            (booking_code, customer_id, vehicle_category_id,
             pickup_address, pickup_lat, pickup_lng,
             delivery_address, delivery_lat, delivery_lng,
             distance_km, estimated_fare, goods_description, status)
         VALUES
            (:booking_code, :customer_id, :vehicle_category_id,
             :pickup_address, :pickup_lat, :pickup_lng,
             :delivery_address, :delivery_lat, :delivery_lng,
             :distance_km, :estimated_fare, :goods_description, "pending")'
    );
    $stmt->execute([
        'booking_code'         => $bookingCode,
        'customer_id'          => $authUser['user_id'],
        'vehicle_category_id'  => $vehicleCategoryId,
        'pickup_address'       => $pickupAddress,
        'pickup_lat'           => $pickupLat,
        'pickup_lng'           => $pickupLng,
        'delivery_address'     => $deliveryAddress,
        'delivery_lat'         => $deliveryLat,
        'delivery_lng'         => $deliveryLng,
        'distance_km'          => $distanceKm,
        'estimated_fare'       => $estimatedFare,
        'goods_description'    => $goodsDescription,
    ]);

    $bookingId = (int) $pdo->lastInsertId();

    $paymentStmt = $pdo->prepare(
        'INSERT INTO payments (booking_id, amount, payment_mode, payment_status)
         VALUES (:booking_id, :amount, :payment_mode, "pending")'
    );
    $paymentStmt->execute([
        'booking_id'    => $bookingId,
        'amount'        => $estimatedFare,
        'payment_mode'  => $paymentMode,
    ]);

    $pdo->commit();

    sendResponse(true, 'Booking created successfully', [
        'booking_id'      => $bookingId,
        'booking_code'    => $bookingCode,
        'status'          => 'pending',
        'distance_km'     => $distanceKm,
        'estimated_fare'  => $estimatedFare,
        'vehicle_category'=> $category['name'],
        'payment_mode'    => $paymentMode,
        'payment_status'  => 'pending',
    ], 201);

} catch (PDOException $e) {
    $pdo->rollBack();
    error_log('Create booking error: ' . $e->getMessage());
    sendResponse(false, 'Could not create booking. Please try again.', null, 500);
}
