<?php
/**
 * GET /api/bookings/history.php?status=pending|accepted|completed|cancelled (optional)
 * Header: Authorization: Bearer <token>   (customer or driver)
 *
 * Customers see bookings they created; drivers see bookings assigned
 * to them. Same endpoint serves both "Booking History" and the
 * "View Booking Status" screens.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../middleware/auth_middleware.php';

requireMethod('GET');

$authUser = authenticateRequest();

$allowedStatuses = ['pending', 'accepted', 'completed', 'cancelled'];
$statusFilter = $_GET['status'] ?? null;

if ($statusFilter !== null && !in_array($statusFilter, $allowedStatuses, true)) {
    sendResponse(false, 'Invalid status filter', null, 400);
}

$pdo = Database::getInstance()->getConnection();

try {
    $ownerColumn = $authUser['role'] === 'driver' ? 'b.driver_id' : 'b.customer_id';

    $sql = 'SELECT b.id, b.booking_code, b.status,
                   b.pickup_address, b.delivery_address,
                   b.distance_km, b.estimated_fare, b.final_fare, b.goods_description,
                   b.created_at, b.accepted_at, b.completed_at,
                   c.name AS customer_name, c.mobile AS customer_mobile,
                   d.name AS driver_name, d.mobile AS driver_mobile,
                   vc.name AS vehicle_category_name,
                   p.payment_mode, p.payment_status
            FROM bookings b
            JOIN users c ON c.id = b.customer_id
            LEFT JOIN users d ON d.id = b.driver_id
            JOIN vehicle_categories vc ON vc.id = b.vehicle_category_id
            LEFT JOIN payments p ON p.booking_id = b.id
            WHERE ' . $ownerColumn . ' = :user_id';

    $params = ['user_id' => $authUser['user_id']];

    if ($statusFilter !== null) {
        $sql .= ' AND b.status = :status';
        $params['status'] = $statusFilter;
    }

    $sql .= ' ORDER BY b.created_at DESC';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $bookings = $stmt->fetchAll();

    foreach ($bookings as &$b) {
        $b['id']             = (int) $b['id'];
        $b['distance_km']    = (float) $b['distance_km'];
        $b['estimated_fare'] = (float) $b['estimated_fare'];
        $b['final_fare']     = $b['final_fare'] !== null ? (float) $b['final_fare'] : null;
    }
    unset($b);

    sendResponse(true, 'Booking history fetched successfully', $bookings);

} catch (PDOException $e) {
    error_log('Booking history error: ' . $e->getMessage());
    sendResponse(false, 'Could not fetch booking history', null, 500);
}
