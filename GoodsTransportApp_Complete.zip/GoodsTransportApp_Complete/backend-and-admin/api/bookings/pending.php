<?php
/**
 * GET /api/bookings/pending.php
 * Header: Authorization: Bearer <token>   (driver only)
 *
 * Returns unassigned bookings that match the driver's own vehicle
 * category — a Bike driver won't see Mini Truck jobs and vice versa.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../middleware/auth_middleware.php';

requireMethod('GET');

$authUser = authenticateRequest();
requireRole($authUser, 'driver');

$pdo = Database::getInstance()->getConnection();

try {
    $driverStmt = $pdo->prepare('SELECT vehicle_category_id FROM users WHERE id = :id LIMIT 1');
    $driverStmt->execute(['id' => $authUser['user_id']]);
    $driver = $driverStmt->fetch();

    if (!$driver || !$driver['vehicle_category_id']) {
        sendResponse(false, 'Your driver profile has no vehicle category set. Please update your profile.', null, 400);
    }

    $stmt = $pdo->prepare(
        'SELECT b.id, b.booking_code, b.pickup_address, b.pickup_lat, b.pickup_lng,
                b.delivery_address, b.delivery_lat, b.delivery_lng,
                b.distance_km, b.estimated_fare, b.goods_description, b.created_at,
                c.name AS customer_name, c.mobile AS customer_mobile,
                vc.name AS vehicle_category_name
         FROM bookings b
         JOIN users c ON c.id = b.customer_id
         JOIN vehicle_categories vc ON vc.id = b.vehicle_category_id
         WHERE b.status = "pending"
           AND b.driver_id IS NULL
           AND b.vehicle_category_id = :vehicle_category_id
         ORDER BY b.created_at ASC'
    );
    $stmt->execute(['vehicle_category_id' => $driver['vehicle_category_id']]);
    $bookings = $stmt->fetchAll();

    foreach ($bookings as &$b) {
        $b['id']             = (int) $b['id'];
        $b['distance_km']    = (float) $b['distance_km'];
        $b['estimated_fare'] = (float) $b['estimated_fare'];
        $b['pickup_lat']     = (float) $b['pickup_lat'];
        $b['pickup_lng']     = (float) $b['pickup_lng'];
        $b['delivery_lat']   = (float) $b['delivery_lat'];
        $b['delivery_lng']   = (float) $b['delivery_lng'];
    }
    unset($b);

    sendResponse(true, 'Pending bookings fetched successfully', $bookings);

} catch (PDOException $e) {
    error_log('Pending bookings error: ' . $e->getMessage());
    sendResponse(false, 'Could not fetch pending bookings', null, 500);
}
