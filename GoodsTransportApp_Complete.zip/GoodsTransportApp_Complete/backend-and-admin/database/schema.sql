-- ============================================================
-- Goods Transport Booking App - Database Schema
-- Engine: InnoDB | Charset: utf8mb4
-- Import this file via phpMyAdmin or:
--   mysql -u USERNAME -p DATABASE_NAME < schema.sql
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+05:30";

-- ------------------------------------------------------------
-- Table: admin
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `username` VARCHAR(50) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `last_login` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_email` (`email`),
  UNIQUE KEY `uq_admin_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: vehicle_categories
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `vehicle_categories` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `icon` VARCHAR(255) DEFAULT NULL COMMENT 'icon filename or emoji code',
  `base_fare` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `per_km_rate` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `capacity` VARCHAR(50) DEFAULT NULL COMMENT 'e.g. Up to 20kg, Up to 500kg',
  `sort_order` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_vc_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: users (customer + driver, distinguished by `role`)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `mobile` VARCHAR(15) NOT NULL,
  `email` VARCHAR(150) DEFAULT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('customer','driver') NOT NULL,
  `profile_image` VARCHAR(255) DEFAULT NULL,
  `vehicle_category_id` INT UNSIGNED DEFAULT NULL COMMENT 'driver only',
  `vehicle_number` VARCHAR(20) DEFAULT NULL COMMENT 'driver only',
  `driving_license` VARCHAR(50) DEFAULT NULL COMMENT 'driver only',
  `is_available` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'driver online/offline toggle',
  `status` ENUM('active','inactive','blocked') NOT NULL DEFAULT 'active',
  `fcm_token` VARCHAR(255) DEFAULT NULL COMMENT 'for push notifications',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_mobile` (`mobile`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_vehicle_category` (`vehicle_category_id`),
  CONSTRAINT `fk_users_vehicle_category` FOREIGN KEY (`vehicle_category_id`)
    REFERENCES `vehicle_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: bookings
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bookings` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_code` VARCHAR(20) NOT NULL,
  `customer_id` INT UNSIGNED NOT NULL,
  `driver_id` INT UNSIGNED DEFAULT NULL,
  `vehicle_category_id` INT UNSIGNED NOT NULL,
  `pickup_address` VARCHAR(500) NOT NULL,
  `pickup_lat` DECIMAL(10,8) NOT NULL,
  `pickup_lng` DECIMAL(11,8) NOT NULL,
  `delivery_address` VARCHAR(500) NOT NULL,
  `delivery_lat` DECIMAL(10,8) NOT NULL,
  `delivery_lng` DECIMAL(11,8) NOT NULL,
  `distance_km` DECIMAL(10,2) DEFAULT NULL,
  `estimated_fare` DECIMAL(10,2) DEFAULT NULL,
  `final_fare` DECIMAL(10,2) DEFAULT NULL,
  `goods_description` VARCHAR(500) DEFAULT NULL,
  `status` ENUM('pending','accepted','completed','cancelled') NOT NULL DEFAULT 'pending',
  `cancel_reason` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted_at` TIMESTAMP NULL DEFAULT NULL,
  `completed_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bookings_code` (`booking_code`),
  KEY `idx_bookings_status` (`status`),
  KEY `idx_bookings_customer` (`customer_id`),
  KEY `idx_bookings_driver` (`driver_id`),
  KEY `idx_bookings_vehicle_category` (`vehicle_category_id`),
  CONSTRAINT `fk_bookings_customer` FOREIGN KEY (`customer_id`)
    REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_bookings_driver` FOREIGN KEY (`driver_id`)
    REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_bookings_vehicle_category` FOREIGN KEY (`vehicle_category_id`)
    REFERENCES `vehicle_categories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table: payments
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` INT UNSIGNED NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_mode` ENUM('cash','online') NOT NULL DEFAULT 'cash',
  `payment_status` ENUM('pending','paid','failed') NOT NULL DEFAULT 'pending',
  `transaction_id` VARCHAR(100) DEFAULT NULL,
  `gateway_order_id` VARCHAR(100) DEFAULT NULL,
  `paid_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payments_booking` (`booking_id`),
  KEY `idx_payments_status` (`payment_status`),
  CONSTRAINT `fk_payments_booking` FOREIGN KEY (`booking_id`)
    REFERENCES `bookings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Default admin login -> username: admin | password: Admin@123
-- CHANGE THIS PASSWORD IMMEDIATELY AFTER FIRST LOGIN
INSERT INTO `admin` (`name`, `email`, `username`, `password`, `status`) VALUES
('Super Admin', 'admin@goodstransport.local', 'admin', '$2y$10$nMlBxIre5YjmQyCg.zENeOW7y3w7XAoIbZxrROrZbv6LFL/OvVsB2', 'active');

-- Default vehicle categories
INSERT INTO `vehicle_categories` (`name`, `icon`, `base_fare`, `per_km_rate`, `capacity`, `sort_order`, `status`) VALUES
('Bike', 'bike.png', 20.00, 6.00, 'Up to 15 kg', 1, 'active'),
('Auto', 'auto.png', 40.00, 9.00, 'Up to 150 kg', 2, 'active'),
('Pickup', 'pickup.png', 80.00, 14.00, 'Up to 750 kg', 3, 'active'),
('Mini Truck', 'minitruck.png', 150.00, 20.00, 'Up to 1500 kg', 4, 'active');
