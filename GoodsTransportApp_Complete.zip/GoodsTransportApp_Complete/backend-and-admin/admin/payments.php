<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/auth_check.php';
requireAdminLogin();

$pdo = Database::getInstance()->getConnection();

// ------------------------------------------------------------------
// Handle admin manual status override (e.g. dispute resolution)
// ------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        setFlash('danger', 'Session expired. Please try again.');
        header('Location: payments.php');
        exit();
    }

    $id     = (int) ($_POST['id'] ?? 0);
    $status = $_POST['payment_status'] ?? '';

    if (!in_array($status, ['pending', 'paid', 'failed'], true)) {
        setFlash('danger', 'Invalid payment status.');
    } else {
        $stmt = $pdo->prepare(
            'UPDATE payments
             SET payment_status = :status,
                 paid_at = CASE WHEN :status2 = "paid" THEN NOW() ELSE paid_at END
             WHERE id = :id'
        );
        $stmt->execute(['status' => $status, 'status2' => $status, 'id' => $id]);
        setFlash('success', 'Payment status updated.');
    }

    header('Location: payments.php' . (!empty($_POST['redirect_query']) ? '?' . $_POST['redirect_query'] : ''));
    exit();
}

// ------------------------------------------------------------------
// Filters
// ------------------------------------------------------------------
$modeFilter   = $_GET['mode'] ?? '';
$statusFilter = $_GET['status'] ?? '';
$search       = trim($_GET['q'] ?? '');

$allowedModes    = ['cash', 'online'];
$allowedStatuses = ['pending', 'paid', 'failed'];

$sql = "SELECT p.*, b.booking_code, b.status AS booking_status,
               c.name AS customer_name, c.mobile AS customer_mobile,
               d.name AS driver_name
        FROM payments p
        JOIN bookings b ON b.id = p.booking_id
        JOIN users c ON c.id = b.customer_id
        LEFT JOIN users d ON d.id = b.driver_id
        WHERE 1=1";
$params = [];

if (in_array($modeFilter, $allowedModes, true)) {
    $sql .= ' AND p.payment_mode = :mode';
    $params['mode'] = $modeFilter;
}
if (in_array($statusFilter, $allowedStatuses, true)) {
    $sql .= ' AND p.payment_status = :status';
    $params['status'] = $statusFilter;
}
if ($search !== '') {
    $sql .= ' AND (b.booking_code LIKE :q OR c.name LIKE :q OR c.mobile LIKE :q)';
    $params['q'] = "%$search%";
}
$sql .= ' ORDER BY p.created_at DESC LIMIT 200';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$payments = $stmt->fetchAll();

$statusCounts = $pdo->query('SELECT payment_status, COUNT(*) c FROM payments GROUP BY payment_status')
                     ->fetchAll(PDO::FETCH_KEY_PAIR);
$totalCollected = (float) $pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_status = 'paid'")->fetchColumn();

$redirectQuery = http_build_query(array_filter(['mode' => $modeFilter, 'status' => $statusFilter, 'q' => $search]));

$flash      = getFlash();
$csrfToken  = csrfToken();
$pageTitle  = 'Payments';
$activePage = 'payments';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <h4 class="mb-0">Payments</h4>
  <div class="text-end">
    <div class="text-muted small">Total Collected</div>
    <div class="fs-5 fw-bold text-success">₹<?= number_format($totalCollected, 2) ?></div>
  </div>
</div>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['message']) ?></div>
<?php endif; ?>

<div class="card p-3 mb-3">
  <form class="row g-2 align-items-end" method="GET" action="payments.php">
    <div class="col-auto">
      <label class="form-label small mb-1">Mode</label>
      <select name="mode" class="form-select form-select-sm">
        <option value="">All</option>
        <option value="cash" <?= $modeFilter === 'cash' ? 'selected' : '' ?>>Cash</option>
        <option value="online" <?= $modeFilter === 'online' ? 'selected' : '' ?>>Online</option>
      </select>
    </div>
    <div class="col-auto">
      <label class="form-label small mb-1">Status</label>
      <select name="status" class="form-select form-select-sm">
        <option value="">All</option>
        <option value="pending" <?= $statusFilter === 'pending' ? 'selected' : '' ?>>Pending</option>
        <option value="paid" <?= $statusFilter === 'paid' ? 'selected' : '' ?>>Paid</option>
        <option value="failed" <?= $statusFilter === 'failed' ? 'selected' : '' ?>>Failed</option>
      </select>
    </div>
    <div class="col-auto flex-grow-1">
      <label class="form-label small mb-1">Search</label>
      <input type="text" name="q" class="form-control form-control-sm" placeholder="Booking code, customer name or mobile" value="<?= htmlspecialchars($search) ?>">
    </div>
    <div class="col-auto">
      <button class="btn btn-sm btn-primary"><i class="bi bi-funnel"></i> Filter</button>
      <a href="payments.php" class="btn btn-sm btn-outline-secondary">Reset</a>
    </div>
  </form>
</div>

<div class="row g-2 mb-3">
  <div class="col-auto"><span class="badge bg-warning-subtle text-warning border border-warning">Pending: <?= (int) ($statusCounts['pending'] ?? 0) ?></span></div>
  <div class="col-auto"><span class="badge bg-success-subtle text-success border border-success">Paid: <?= (int) ($statusCounts['paid'] ?? 0) ?></span></div>
  <div class="col-auto"><span class="badge bg-danger-subtle text-danger border border-danger">Failed: <?= (int) ($statusCounts['failed'] ?? 0) ?></span></div>
</div>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table align-middle">
      <thead>
        <tr>
          <th>Booking</th><th>Customer</th><th>Driver</th><th>Mode</th>
          <th>Amount</th><th>Transaction ID</th><th>Status</th><th>Date</th><th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($payments)): ?>
          <tr><td colspan="9" class="text-center text-muted py-4">No payments found</td></tr>
        <?php else: foreach ($payments as $p): ?>
          <tr>
            <td class="fw-semibold"><?= htmlspecialchars($p['booking_code']) ?></td>
            <td><?= htmlspecialchars($p['customer_name']) ?><br><span class="text-muted small"><?= htmlspecialchars($p['customer_mobile']) ?></span></td>
            <td><?= htmlspecialchars($p['driver_name'] ?? '—') ?></td>
            <td><span class="badge bg-secondary-subtle text-secondary"><?= ucfirst($p['payment_mode']) ?></span></td>
            <td class="fw-semibold">₹<?= number_format((float) $p['amount'], 2) ?></td>
            <td class="small text-muted"><?= htmlspecialchars($p['transaction_id'] ?? '—') ?></td>
            <td><span class="badge badge-status-<?= $p['payment_status'] ?>"><?= ucfirst($p['payment_status']) ?></span></td>
            <td class="text-muted small"><?= date('d M Y, h:i A', strtotime($p['created_at'])) ?></td>
            <td class="text-end">
              <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#statusModal"
                      onclick="openStatusModal(<?= (int) $p['id'] ?>, '<?= htmlspecialchars($p['booking_code']) ?>', '<?= $p['payment_status'] ?>')">
                <i class="bi bi-pencil-square"></i>
              </button>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="statusModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST" action="payments.php">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
      <input type="hidden" name="id" id="statusId">
      <input type="hidden" name="redirect_query" value="<?= htmlspecialchars($redirectQuery) ?>">
      <div class="modal-header">
        <h5 class="modal-title">Update Payment Status — <span id="statusBookingCode"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p class="text-muted small">Use this only to correct a dispute or gateway mismatch. Normally the customer app (online) or driver app (cash) updates this automatically.</p>
        <label class="form-label">Payment Status</label>
        <select name="payment_status" id="statusSelect" class="form-select">
          <option value="pending">Pending</option>
          <option value="paid">Paid</option>
          <option value="failed">Failed</option>
        </select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
function openStatusModal(id, bookingCode, currentStatus) {
  document.getElementById('statusId').value = id;
  document.getElementById('statusBookingCode').textContent = bookingCode;
  document.getElementById('statusSelect').value = currentStatus;
}
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
