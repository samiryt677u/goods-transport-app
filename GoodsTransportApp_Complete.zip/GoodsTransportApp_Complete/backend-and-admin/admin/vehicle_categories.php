<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/auth_check.php';
requireAdminLogin();

$pdo = Database::getInstance()->getConnection();

// ------------------------------------------------------------------
// Handle form submissions (Add / Edit / Delete) — Post/Redirect/Get
// ------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        setFlash('danger', 'Session expired. Please try again.');
        header('Location: vehicle_categories.php');
        exit();
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name       = trim($_POST['name'] ?? '');
        $icon       = trim($_POST['icon'] ?? '');
        $baseFare   = $_POST['base_fare'] ?? '';
        $perKmRate  = $_POST['per_km_rate'] ?? '';
        $capacity   = trim($_POST['capacity'] ?? '');
        $sortOrder  = (int) ($_POST['sort_order'] ?? 0);
        $status     = ($_POST['status'] ?? 'active') === 'active' ? 'active' : 'inactive';

        if ($name === '' || !is_numeric($baseFare) || !is_numeric($perKmRate) || $baseFare < 0 || $perKmRate < 0) {
            setFlash('danger', 'Please provide a valid name, base fare, and per-km rate.');
            header('Location: vehicle_categories.php');
            exit();
        }

        if ($action === 'add') {
            $stmt = $pdo->prepare(
                'INSERT INTO vehicle_categories (name, icon, base_fare, per_km_rate, capacity, sort_order, status)
                 VALUES (:name, :icon, :base_fare, :per_km_rate, :capacity, :sort_order, :status)'
            );
            $stmt->execute([
                'name'        => $name,
                'icon'        => $icon ?: null,
                'base_fare'   => $baseFare,
                'per_km_rate' => $perKmRate,
                'capacity'    => $capacity ?: null,
                'sort_order'  => $sortOrder,
                'status'      => $status,
            ]);
            setFlash('success', 'Vehicle category added successfully.');
        } else {
            $id = (int) ($_POST['id'] ?? 0);
            $stmt = $pdo->prepare(
                'UPDATE vehicle_categories
                 SET name = :name, icon = :icon, base_fare = :base_fare, per_km_rate = :per_km_rate,
                     capacity = :capacity, sort_order = :sort_order, status = :status
                 WHERE id = :id'
            );
            $stmt->execute([
                'name'        => $name,
                'icon'        => $icon ?: null,
                'base_fare'   => $baseFare,
                'per_km_rate' => $perKmRate,
                'capacity'    => $capacity ?: null,
                'sort_order'  => $sortOrder,
                'status'      => $status,
                'id'          => $id,
            ]);
            setFlash('success', 'Vehicle category updated successfully.');
        }
    } elseif ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);

        // Block delete if drivers or bookings still reference this category
        $inUse = $pdo->prepare(
            '(SELECT id FROM users WHERE vehicle_category_id = :id1 LIMIT 1)
             UNION
             (SELECT id FROM bookings WHERE vehicle_category_id = :id2 LIMIT 1)'
        );
        $inUse->execute(['id1' => $id, 'id2' => $id]);

        if ($inUse->fetch()) {
            setFlash('danger', 'Cannot delete: this category is already used by drivers or bookings. Mark it inactive instead.');
        } else {
            $stmt = $pdo->prepare('DELETE FROM vehicle_categories WHERE id = :id');
            $stmt->execute(['id' => $id]);
            setFlash('success', 'Vehicle category deleted.');
        }
    }

    header('Location: vehicle_categories.php');
    exit();
}

// ------------------------------------------------------------------
// Fetch list for display
// ------------------------------------------------------------------
$categories = $pdo->query('SELECT * FROM vehicle_categories ORDER BY sort_order ASC, id ASC')->fetchAll();

$flash      = getFlash();
$csrfToken  = csrfToken();
$pageTitle  = 'Vehicle Categories';
$activePage = 'vehicle_categories';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
  <h4 class="mb-0">Vehicle Categories</h4>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#categoryModal" onclick="openAddModal()">
    <i class="bi bi-plus-lg me-1"></i>Add Category
  </button>
</div>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['message']) ?></div>
<?php endif; ?>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table align-middle">
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Base Fare</th>
          <th>Per KM Rate</th>
          <th>Capacity</th>
          <th>Sort Order</th>
          <th>Status</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($categories)): ?>
          <tr><td colspan="8" class="text-center text-muted py-4">No vehicle categories yet</td></tr>
        <?php else: foreach ($categories as $c): ?>
          <tr>
            <td><?= (int) $c['id'] ?></td>
            <td class="fw-semibold"><?= htmlspecialchars($c['name']) ?></td>
            <td>₹<?= number_format((float) $c['base_fare'], 2) ?></td>
            <td>₹<?= number_format((float) $c['per_km_rate'], 2) ?>/km</td>
            <td><?= htmlspecialchars($c['capacity'] ?? '—') ?></td>
            <td><?= (int) $c['sort_order'] ?></td>
            <td>
              <span class="badge <?= $c['status'] === 'active' ? 'bg-success' : 'bg-secondary' ?>">
                <?= ucfirst($c['status']) ?>
              </span>
            </td>
            <td class="text-end">
              <button class="btn btn-sm btn-outline-primary"
                      data-bs-toggle="modal" data-bs-target="#categoryModal"
                      onclick='openEditModal(<?= json_encode($c) ?>)'>
                <i class="bi bi-pencil"></i>
              </button>
              <button class="btn btn-sm btn-outline-danger" onclick="confirmDelete(<?= (int) $c['id'] ?>, '<?= htmlspecialchars($c['name'], ENT_QUOTES) ?>')">
                <i class="bi bi-trash"></i>
              </button>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="categoryModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST" action="vehicle_categories.php" id="categoryForm">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
      <input type="hidden" name="action" id="formAction" value="add">
      <input type="hidden" name="id" id="categoryId" value="">
      <div class="modal-header">
        <h5 class="modal-title" id="categoryModalTitle">Add Vehicle Category</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Name *</label>
          <input type="text" name="name" id="fieldName" class="form-control" required>
        </div>
        <div class="row">
          <div class="col-6 mb-3">
            <label class="form-label">Base Fare (₹) *</label>
            <input type="number" step="0.01" min="0" name="base_fare" id="fieldBaseFare" class="form-control" required>
          </div>
          <div class="col-6 mb-3">
            <label class="form-label">Per KM Rate (₹) *</label>
            <input type="number" step="0.01" min="0" name="per_km_rate" id="fieldPerKmRate" class="form-control" required>
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label">Capacity (display text)</label>
          <input type="text" name="capacity" id="fieldCapacity" class="form-control" placeholder="e.g. Up to 750 kg">
        </div>
        <div class="mb-3">
          <label class="form-label">Icon (filename, optional)</label>
          <input type="text" name="icon" id="fieldIcon" class="form-control" placeholder="e.g. pickup.png">
        </div>
        <div class="row">
          <div class="col-6 mb-3">
            <label class="form-label">Sort Order</label>
            <input type="number" name="sort_order" id="fieldSortOrder" class="form-control" value="0">
          </div>
          <div class="col-6 mb-3">
            <label class="form-label">Status</label>
            <select name="status" id="fieldStatus" class="form-select">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Category</button>
      </div>
    </form>
  </div>
</div>

<!-- Delete confirm form (submitted via JS) -->
<form method="POST" action="vehicle_categories.php" id="deleteForm" class="d-none">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
  <input type="hidden" name="action" value="delete">
  <input type="hidden" name="id" id="deleteId" value="">
</form>

<script>
function openAddModal() {
  document.getElementById('categoryModalTitle').textContent = 'Add Vehicle Category';
  document.getElementById('formAction').value = 'add';
  document.getElementById('categoryForm').reset();
  document.getElementById('categoryId').value = '';
}

function openEditModal(category) {
  document.getElementById('categoryModalTitle').textContent = 'Edit Vehicle Category';
  document.getElementById('formAction').value = 'edit';
  document.getElementById('categoryId').value = category.id;
  document.getElementById('fieldName').value = category.name;
  document.getElementById('fieldBaseFare').value = category.base_fare;
  document.getElementById('fieldPerKmRate').value = category.per_km_rate;
  document.getElementById('fieldCapacity').value = category.capacity || '';
  document.getElementById('fieldIcon').value = category.icon || '';
  document.getElementById('fieldSortOrder').value = category.sort_order;
  document.getElementById('fieldStatus').value = category.status;
}

function confirmDelete(id, name) {
  if (confirm('Delete vehicle category "' + name + '"? This cannot be undone.')) {
    document.getElementById('deleteId').value = id;
    document.getElementById('deleteForm').submit();
  }
}
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
