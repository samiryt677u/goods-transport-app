<?php
/**
 * Shared sidebar. Expects $activePage to be set by the including page,
 * e.g. $activePage = 'dashboard';
 */
$activePage = $activePage ?? '';

function navLink(string $page, string $href, string $icon, string $label, string $active): string
{
    $isActive = $page === $active ? 'active' : '';
    return '<a href="' . $href . '" class="nav-link ' . $isActive . '">'
         . '<i class="bi ' . $icon . ' me-2"></i>' . $label . '</a>';
}
?>
<aside class="app-sidebar" id="appSidebar">
  <nav class="nav flex-column p-2">
    <?= navLink('dashboard', 'dashboard.php', 'bi-speedometer2', 'Dashboard', $activePage) ?>
    <?= navLink('customers', 'customers.php', 'bi-people', 'Customers', $activePage) ?>
    <?= navLink('drivers', 'drivers.php', 'bi-person-badge', 'Drivers', $activePage) ?>
    <?= navLink('vehicle_categories', 'vehicle_categories.php', 'bi-truck-front', 'Vehicle Categories', $activePage) ?>
    <?= navLink('bookings', 'bookings.php', 'bi-clipboard-check', 'Bookings', $activePage) ?>
    <?= navLink('payments', 'payments.php', 'bi-cash-coin', 'Payments', $activePage) ?>
  </nav>
</aside>

<main class="app-main p-3 p-md-4">
