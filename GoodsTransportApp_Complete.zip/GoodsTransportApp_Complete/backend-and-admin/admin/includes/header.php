<?php
/**
 * Shared header. Include after requireAdminLogin() has passed.
 * Expects an optional $pageTitle variable to be set before including.
 */
$pageTitle = $pageTitle ?? 'Dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?> | Goods Transport Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark app-navbar sticky-top">
  <div class="container-fluid px-3">
    <button class="btn btn-link text-white d-lg-none me-2" id="sidebarToggle" type="button">
      <i class="bi bi-list fs-4"></i>
    </button>
    <a class="navbar-brand fw-semibold" href="dashboard.php">
      <i class="bi bi-truck me-1"></i> Goods Transport Admin
    </a>
    <div class="ms-auto d-flex align-items-center">
      <span class="text-white-50 me-3 d-none d-sm-inline">
        <i class="bi bi-person-circle me-1"></i><?= htmlspecialchars(currentAdminName()) ?>
      </span>
      <a href="logout.php" class="btn btn-sm btn-outline-light">
        <i class="bi bi-box-arrow-right me-1"></i>Logout
      </a>
    </div>
  </div>
</nav>

<div class="app-layout">
