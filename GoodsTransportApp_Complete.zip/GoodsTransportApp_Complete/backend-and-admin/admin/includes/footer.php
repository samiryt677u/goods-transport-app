</main>
</div><!-- /.app-layout -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('appSidebar').classList.toggle('show');
});
</script>
</body>
</html>
