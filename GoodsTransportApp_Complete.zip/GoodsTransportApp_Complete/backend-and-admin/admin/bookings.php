<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/auth_check.php';
requireAdminLogin();

$pdo = Database::getInstance()->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        setFlash('danger', 'Session expired. Please try again.');
        header('Location: bookings.php');
        exit();
    }

    $action = $_POST['action'] ?? '';
    $id     = (int) ($_POST['id'] ?? 0);

    if ($action === 'cancel') {
        $reason = trim($_POST['cancel_reason'] ?? 'Cancelled by admin');
        $stmt = $pdo->prepare(
            "UPDATE bookings SET status = 'cancelled', cancel_reason = :reason
             WHERE id = :id AND status IN ('pending', 'accepted')"
        );
        $stmt->execute(['reason' => $reason, 'id' => $id]);

        if ($stmt->rowCount() > 0) {
            setFlash('success', 'Booking cancelled.');
        } else {
            setFlash('danger', 'Booking could not be cancelled (it may already be completed/cancelled).');
        }
    }

    header('Location: bookings.php' . (!empty($_POST['redirect_status']) ? '?status=' . urlencode($_POST['redirect_status']) : ''));
    exit();
}

$statusFilter = $_GET['status'] ?? '';
$allowedStatuses = ['pending', 'accepted', 'completed', 'cancelled'];

$sql = "SELECT b.*, c.name AS customer_name, c.mobile AS customer_mobile,
               d.name AS driver_name, d.mobile AS driver_mobile,
               vc.name AS vehicle_category_name,
               p.payment_mode, p.payment_status
        FROM bookings b
        JOIN users c ON c.id = b.customer_id
        LEFT JOIN users d ON d.id = b.driver_id
        JOIN vehicle_categories vc ON vc.id = b.vehicle_category_id
        LEFT JOIN payments p ON p.booking_id = b.id";
$params = [];
if (in_array($statusFilter, $allowedStatuses, true)) {
    $sql .= ' WHERE b.status = :status';
    $params['status'] = $statusFilter;
}
$sql .= ' ORDER BY b.created_at DESC LIMIT 200';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$bookings = $stmt->fetchAll();

$counts = $pdo->query(
    "SELECT status, COUNT(*) c FROM bookings GROUP BY status"
)->fetchAll(PDO::FETCH_KEY_PAIR);

$flash      = getFlash();
$csrfToken  = csrfToken();
$pageTitle  = 'Bookings';
$activePage = 'bookings';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/sidebar.php';
?>

<h4 class="mb-4">Bookings</h4>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['message']) ?></div>
<?php endif; ?>

<ul class="nav nav-pills mb-3">
  <li class="nav-item"><a class="nav-link <?= $statusFilter === '' ? 'active' : '' ?>" href="bookings.php">All (<?= array_sum($counts) ?>)</a></li>
  <li class="nav-item"><a class="nav-link <?= $statusFilter === 'pending' ? 'active' : '' ?>" href="bookings.php?status=pending">Pending (<?= $counts['pending'] ?? 0 ?>)</a></li>
  <li class="nav-item"><a class="nav-link <?= $statusFilter === 'accepted' ? 'active' : '' ?>" href="bookings.php?status=accepted">Accepted (<?= $counts['accepted'] ?? 0 ?>)</a></li>
  <li class="nav-item"><a class="nav-link <?= $statusFilter === 'completed' ? 'active' : '' ?>" href="bookings.php?status=completed">Completed (<?= $counts['completed'] ?? 0 ?>)</a></li>
  <li class="nav-item"><a class="nav-link <?= $statusFilter === 'cancelled' ? 'active' : '' ?>" href="bookings.php?status=cancelled">Cancelled (<?= $counts['cancelled'] ?? 0 ?>)</a></li>
</ul>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table align-middle">
      <thead>
        <tr>
          <th>Code</th><th>Customer</th><th>Driver</th><th>Vehicle</th>
          <th>Fare</th><th>Payment</th><th>Status</th><th>Date</th><th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($bookings)): ?>
          <tr><td colspan="9" class="text-center text-muted py-4">No bookings found</td></tr>
        <?php else: foreach ($bookings as $b): ?>
          <tr>
            <td class="fw-semibold"><?= htmlspecialchars($b['booking_code']) ?></td>
            <td><?= htmlspecialchars($b['customer_name']) ?><br><span class="text-muted small"><?= htmlspecialchars($b['customer_mobile']) ?></span></td>
            <td><?= htmlspecialchars($b['driver_name'] ?? '—') ?></td>
            <td><?= htmlspecialchars($b['vehicle_category_name']) ?></td>
            <td>₹<?= number_format((float) ($b['final_fare'] ?? $b['estimated_fare']), 2) ?></td>
            <td>
              <?= htmlspecialchars(ucfirst($b['payment_mode'] ?? '—')) ?>
              <span class="badge badge-status-<?= $b['payment_status'] ?? 'pending' ?>"><?= ucfirst($b['payment_status'] ?? 'pending') ?></span>
            </td>
            <td><span class="badge badge-status-<?= $b['status'] ?>"><?= ucfirst($b['status']) ?></span></td>
            <td class="text-muted small"><?= date('d M Y, h:i A', strtotime($b['created_at'])) ?></td>
            <td class="text-end">
              <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#viewModal" onclick='openView(<?= json_encode($b) ?>)'><i class="bi bi-eye"></i></button>
              <?php if (in_array($b['status'], ['pending', 'accepted'], true)): ?>
                <button class="btn btn-sm btn-outline-danger" onclick="cancelBooking(<?= (int) $b['id'] ?>, '<?= htmlspecialchars($b['booking_code']) ?>')"><i class="bi bi-x-circle"></i></button>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="viewModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Booking Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="viewModalBody"></div>
    </div>
  </div>
</div>

<form method="POST" action="bookings.php" id="cancelForm" class="d-none">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
  <input type="hidden" name="action" value="cancel">
  <input type="hidden" name="id" id="cancelId">
  <input type="hidden" name="redirect_status" value="<?= htmlspecialchars($statusFilter) ?>">
</form>

<script>
function openView(b) {
  document.getElementById('viewModalBody').innerHTML = `
    <div class="row g-3">
      <div class="col-6"><strong>Booking Code:</strong> ${b.booking_code}</div>
      <div class="col-6"><strong>Status:</strong> <span class="badge badge-status-${b.status}">${b.status}</span></div>
      <div class="col-6"><strong>Customer:</strong> ${b.customer_name} (${b.customer_mobile})</div>
      <div class="col-6"><strong>Driver:</strong> ${b.driver_name || '—'} ${b.driver_mobile ? '(' + b.driver_mobile + ')' : ''}</div>
      <div class="col-12"><strong>Pickup:</strong> ${b.pickup_address}</div>
      <div class="col-12"><strong>Delivery:</strong> ${b.delivery_address}</div>
      <div class="col-6"><strong>Distance:</strong> ${b.distance_km} km</div>
      <div class="col-6"><strong>Fare:</strong> ₹${b.final_fare || b.estimated_fare}</div>
      <div class="col-6"><strong>Payment:</strong> ${b.payment_mode || '—'} (${b.payment_status || 'pending'})</div>
      <div class="col-6"><strong>Goods:</strong> ${b.goods_description || '—'}</div>
      <div class="col-12"><strong>Cancel Reason:</strong> ${b.cancel_reason || '—'}</div>
    </div>`;
}

function cancelBooking(id, code) {
  if (confirm('Cancel booking ' + code + '?')) {
    document.getElementById('cancelId').value = id;
    document.getElementById('cancelForm').submit();
  }
}
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
