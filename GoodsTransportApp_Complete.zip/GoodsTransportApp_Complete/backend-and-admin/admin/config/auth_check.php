<?php
/**
 * Include this on every protected admin page (after config.php) and
 * call requireAdminLogin() at the top of the file.
 */

function requireAdminLogin(): void
{
    if (empty($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit();
    }
}

function currentAdminName(): string
{
    return $_SESSION['admin_name'] ?? 'Admin';
}

/**
 * Simple CSRF token helpers — one token per session, checked on every
 * state-changing admin form submission.
 */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(?string $token): bool
{
    return !empty($token) && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * One-time flash messages for the Post/Redirect/Get pattern used on
 * every admin CRUD page (add/edit/delete then redirect back).
 */
function setFlash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array
{
    if (empty($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}
