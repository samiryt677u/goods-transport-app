<?php
/**
 * Admin Panel Config
 * --------------------
 * Starts the admin session and reuses the same PDO connection class
 * as the REST API, so DB credentials live in exactly one place:
 * /api/config/database.php
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
date_default_timezone_set('Asia/Kolkata');

require_once __DIR__ . '/../../api/config/database.php';
require_once __DIR__ . '/../../api/config/functions.php';

define('ADMIN_BASE_URL', '/admin'); // change if the admin folder is mounted elsewhere
