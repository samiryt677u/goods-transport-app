<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/auth_check.php';
requireAdminLogin();

$pdo = Database::getInstance()->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        setFlash('danger', 'Session expired. Please try again.');
        header('Location: customers.php');
        exit();
    }

    $action = $_POST['action'] ?? '';
    $id     = (int) ($_POST['id'] ?? 0);

    if ($action === 'edit') {
        $name   = trim($_POST['name'] ?? '');
        $email  = trim($_POST['email'] ?? '');
        $status = in_array($_POST['status'] ?? '', ['active', 'inactive', 'blocked'], true) ? $_POST['status'] : 'active';

        if ($name === '') {
            setFlash('danger', 'Name is required.');
        } elseif ($email !== '' && !validateEmail($email)) {
            setFlash('danger', 'Enter a valid email address.');
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name = :name, email = :email, status = :status WHERE id = :id AND role = 'customer'");
            $stmt->execute(['name' => $name, 'email' => $email ?: null, 'status' => $status, 'id' => $id]);
            setFlash('success', 'Customer updated successfully.');
        }
    } elseif ($action === 'delete') {
        $bookingCheck = $pdo->prepare('SELECT id FROM bookings WHERE customer_id = :id LIMIT 1');
        $bookingCheck->execute(['id' => $id]);

        if ($bookingCheck->fetch()) {
            setFlash('danger', 'Cannot delete: this customer has booking history. Mark them blocked instead.');
        } else {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id AND role = 'customer'");
            $stmt->execute(['id' => $id]);
            setFlash('success', 'Customer deleted.');
        }
    }

    header('Location: customers.php');
    exit();
}

$search = trim($_GET['q'] ?? '');
$sql = "SELECT id, name, mobile, email, status, created_at,
        (SELECT COUNT(*) FROM bookings WHERE customer_id = users.id) AS total_bookings
        FROM users WHERE role = 'customer'";
$params = [];
if ($search !== '') {
    $sql .= ' AND (name LIKE :q OR mobile LIKE :q)';
    $params['q'] = "%$search%";
}
$sql .= ' ORDER BY created_at DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$customers = $stmt->fetchAll();

$flash      = getFlash();
$csrfToken  = csrfToken();
$pageTitle  = 'Customers';
$activePage = 'customers';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <h4 class="mb-0">Customers</h4>
  <form class="d-flex" method="GET" action="customers.php">
    <input type="text" name="q" class="form-control form-control-sm me-2" placeholder="Search name or mobile" value="<?= htmlspecialchars($search) ?>" style="width:220px">
    <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-search"></i></button>
  </form>
</div>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['message']) ?></div>
<?php endif; ?>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table align-middle">
      <thead>
        <tr>
          <th>#</th><th>Name</th><th>Mobile</th><th>Email</th><th>Bookings</th><th>Status</th><th>Joined</th><th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($customers)): ?>
          <tr><td colspan="8" class="text-center text-muted py-4">No customers found</td></tr>
        <?php else: foreach ($customers as $c): ?>
          <tr>
            <td><?= (int) $c['id'] ?></td>
            <td class="fw-semibold"><?= htmlspecialchars($c['name']) ?></td>
            <td><?= htmlspecialchars($c['mobile']) ?></td>
            <td><?= htmlspecialchars($c['email'] ?? '—') ?></td>
            <td><span class="badge bg-primary-subtle text-primary"><?= (int) $c['total_bookings'] ?></span></td>
            <td>
              <?php $badgeClass = ['active' => 'bg-success', 'inactive' => 'bg-secondary', 'blocked' => 'bg-danger'][$c['status']]; ?>
              <span class="badge <?= $badgeClass ?>"><?= ucfirst($c['status']) ?></span>
            </td>
            <td class="text-muted small"><?= date('d M Y', strtotime($c['created_at'])) ?></td>
            <td class="text-end">
              <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editModal"
                      onclick='openEdit(<?= json_encode($c) ?>)'><i class="bi bi-pencil"></i></button>
              <button class="btn btn-sm btn-outline-danger" onclick="confirmDelete(<?= (int) $c['id'] ?>, '<?= htmlspecialchars($c['name'], ENT_QUOTES) ?>')"><i class="bi bi-trash"></i></button>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST" action="customers.php">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="editId">
      <div class="modal-header">
        <h5 class="modal-title">Edit Customer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" id="editName" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" id="editEmail" class="form-control"></div>
        <div class="mb-3">
          <label class="form-label">Status</label>
          <select name="status" id="editStatus" class="form-select">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="blocked">Blocked</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<form method="POST" action="customers.php" id="deleteForm" class="d-none">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
  <input type="hidden" name="action" value="delete">
  <input type="hidden" name="id" id="deleteId">
</form>

<script>
function openEdit(c) {
  document.getElementById('editId').value = c.id;
  document.getElementById('editName').value = c.name;
  document.getElementById('editEmail').value = c.email || '';
  document.getElementById('editStatus').value = c.status;
}
function confirmDelete(id, name) {
  if (confirm('Delete customer "' + name + '"? This cannot be undone.')) {
    document.getElementById('deleteId').value = id;
    document.getElementById('deleteForm').submit();
  }
}
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
