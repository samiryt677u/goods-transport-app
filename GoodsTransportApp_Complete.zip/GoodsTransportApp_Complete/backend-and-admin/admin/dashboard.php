<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/auth_check.php';
requireAdminLogin();

$pdo = Database::getInstance()->getConnection();

$totalCustomers   = (int) $pdo->query("SELECT COUNT(*) c FROM users WHERE role = 'customer'")->fetch()['c'];
$totalDrivers     = (int) $pdo->query("SELECT COUNT(*) c FROM users WHERE role = 'driver'")->fetch()['c'];
$totalBookings    = (int) $pdo->query("SELECT COUNT(*) c FROM bookings")->fetch()['c'];
$pendingBookings  = (int) $pdo->query("SELECT COUNT(*) c FROM bookings WHERE status = 'pending'")->fetch()['c'];
$acceptedBookings = (int) $pdo->query("SELECT COUNT(*) c FROM bookings WHERE status = 'accepted'")->fetch()['c'];
$completedBookings = (int) $pdo->query("SELECT COUNT(*) c FROM bookings WHERE status = 'completed'")->fetch()['c'];

$recentBookings = $pdo->query(
    "SELECT b.booking_code, b.status, b.created_at,
            c.name AS customer_name, d.name AS driver_name, vc.name AS vehicle_name
     FROM bookings b
     JOIN users c ON c.id = b.customer_id
     LEFT JOIN users d ON d.id = b.driver_id
     JOIN vehicle_categories vc ON vc.id = b.vehicle_category_id
     ORDER BY b.created_at DESC
     LIMIT 8"
)->fetchAll();

$pageTitle  = 'Dashboard';
$activePage = 'dashboard';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/sidebar.php';
?>

<h4 class="mb-4">Dashboard</h4>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-4 col-xl-2">
    <div class="card stat-card p-3">
      <div class="stat-icon bg-primary bg-opacity-10 text-primary mb-2"><i class="bi bi-people"></i></div>
      <div class="fs-4 fw-bold"><?= $totalCustomers ?></div>
      <div class="text-muted small">Total Customers</div>
    </div>
  </div>
  <div class="col-6 col-md-4 col-xl-2">
    <div class="card stat-card p-3">
      <div class="stat-icon bg-success bg-opacity-10 text-success mb-2"><i class="bi bi-person-badge"></i></div>
      <div class="fs-4 fw-bold"><?= $totalDrivers ?></div>
      <div class="text-muted small">Total Drivers</div>
    </div>
  </div>
  <div class="col-6 col-md-4 col-xl-2">
    <div class="card stat-card p-3">
      <div class="stat-icon bg-dark bg-opacity-10 text-dark mb-2"><i class="bi bi-clipboard-check"></i></div>
      <div class="fs-4 fw-bold"><?= $totalBookings ?></div>
      <div class="text-muted small">Total Bookings</div>
    </div>
  </div>
  <div class="col-6 col-md-4 col-xl-2">
    <div class="card stat-card p-3">
      <div class="stat-icon bg-warning bg-opacity-10 text-warning mb-2"><i class="bi bi-hourglass-split"></i></div>
      <div class="fs-4 fw-bold"><?= $pendingBookings ?></div>
      <div class="text-muted small">Pending</div>
    </div>
  </div>
  <div class="col-6 col-md-4 col-xl-2">
    <div class="card stat-card p-3">
      <div class="stat-icon bg-info bg-opacity-10 text-info mb-2"><i class="bi bi-arrow-repeat"></i></div>
      <div class="fs-4 fw-bold"><?= $acceptedBookings ?></div>
      <div class="text-muted small">Accepted</div>
    </div>
  </div>
  <div class="col-6 col-md-4 col-xl-2">
    <div class="card stat-card p-3">
      <div class="stat-icon bg-success bg-opacity-10 text-success mb-2"><i class="bi bi-check-circle"></i></div>
      <div class="fs-4 fw-bold"><?= $completedBookings ?></div>
      <div class="text-muted small">Completed</div>
    </div>
  </div>
</div>

<div class="card p-3">
  <h6 class="mb-3">Recent Bookings</h6>
  <div class="table-responsive">
    <table class="table align-middle">
      <thead>
        <tr>
          <th>Booking Code</th>
          <th>Customer</th>
          <th>Driver</th>
          <th>Vehicle</th>
          <th>Status</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($recentBookings)): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">No bookings yet</td></tr>
        <?php else: foreach ($recentBookings as $b): ?>
          <tr>
            <td class="fw-semibold"><?= htmlspecialchars($b['booking_code']) ?></td>
            <td><?= htmlspecialchars($b['customer_name']) ?></td>
            <td><?= htmlspecialchars($b['driver_name'] ?? '—') ?></td>
            <td><?= htmlspecialchars($b['vehicle_name']) ?></td>
            <td><span class="badge badge-status-<?= $b['status'] ?>"><?= ucfirst($b['status']) ?></span></td>
            <td class="text-muted small"><?= date('d M Y, h:i A', strtotime($b['created_at'])) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
