<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/auth_check.php';
requireAdminLogin();

$pdo = Database::getInstance()->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        setFlash('danger', 'Session expired. Please try again.');
        header('Location: drivers.php');
        exit();
    }

    $action = $_POST['action'] ?? '';
    $id     = (int) ($_POST['id'] ?? 0);

    if ($action === 'edit') {
        $name              = trim($_POST['name'] ?? '');
        $email             = trim($_POST['email'] ?? '');
        $vehicleCategoryId = (int) ($_POST['vehicle_category_id'] ?? 0);
        $vehicleNumber     = trim($_POST['vehicle_number'] ?? '');
        $drivingLicense    = trim($_POST['driving_license'] ?? '');
        $status            = in_array($_POST['status'] ?? '', ['active', 'inactive', 'blocked'], true) ? $_POST['status'] : 'active';

        if ($name === '' || $vehicleNumber === '' || $vehicleCategoryId <= 0) {
            setFlash('danger', 'Name, vehicle category, and vehicle number are required.');
        } elseif ($email !== '' && !validateEmail($email)) {
            setFlash('danger', 'Enter a valid email address.');
        } else {
            $stmt = $pdo->prepare(
                "UPDATE users SET name = :name, email = :email, vehicle_category_id = :vc,
                 vehicle_number = :vn, driving_license = :dl, status = :status
                 WHERE id = :id AND role = 'driver'"
            );
            $stmt->execute([
                'name' => $name, 'email' => $email ?: null, 'vc' => $vehicleCategoryId,
                'vn' => $vehicleNumber, 'dl' => $drivingLicense ?: null, 'status' => $status, 'id' => $id,
            ]);
            setFlash('success', 'Driver updated successfully.');
        }
    } elseif ($action === 'delete') {
        $bookingCheck = $pdo->prepare('SELECT id FROM bookings WHERE driver_id = :id LIMIT 1');
        $bookingCheck->execute(['id' => $id]);

        if ($bookingCheck->fetch()) {
            setFlash('danger', 'Cannot delete: this driver has booking history. Mark them blocked instead.');
        } else {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id AND role = 'driver'");
            $stmt->execute(['id' => $id]);
            setFlash('success', 'Driver deleted.');
        }
    }

    header('Location: drivers.php');
    exit();
}

$search = trim($_GET['q'] ?? '');
$sql = "SELECT u.id, u.name, u.mobile, u.email, u.vehicle_category_id, u.vehicle_number,
               u.driving_license, u.is_available, u.status, u.created_at, vc.name AS vehicle_category_name,
               (SELECT COUNT(*) FROM bookings WHERE driver_id = u.id) AS total_bookings
        FROM users u LEFT JOIN vehicle_categories vc ON vc.id = u.vehicle_category_id
        WHERE u.role = 'driver'";
$params = [];
if ($search !== '') {
    $sql .= ' AND (u.name LIKE :q OR u.mobile LIKE :q OR u.vehicle_number LIKE :q)';
    $params['q'] = "%$search%";
}
$sql .= ' ORDER BY u.created_at DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$drivers = $stmt->fetchAll();

$categories = $pdo->query("SELECT id, name FROM vehicle_categories ORDER BY sort_order ASC")->fetchAll();

$flash      = getFlash();
$csrfToken  = csrfToken();
$pageTitle  = 'Drivers';
$activePage = 'drivers';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/sidebar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <h4 class="mb-0">Drivers</h4>
  <form class="d-flex" method="GET" action="drivers.php">
    <input type="text" name="q" class="form-control form-control-sm me-2" placeholder="Search name, mobile, vehicle#" value="<?= htmlspecialchars($search) ?>" style="width:240px">
    <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-search"></i></button>
  </form>
</div>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['message']) ?></div>
<?php endif; ?>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table align-middle">
      <thead>
        <tr>
          <th>#</th><th>Name</th><th>Mobile</th><th>Vehicle</th><th>Vehicle #</th>
          <th>Online</th><th>Bookings</th><th>Status</th><th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($drivers)): ?>
          <tr><td colspan="9" class="text-center text-muted py-4">No drivers found</td></tr>
        <?php else: foreach ($drivers as $d): ?>
          <tr>
            <td><?= (int) $d['id'] ?></td>
            <td class="fw-semibold"><?= htmlspecialchars($d['name']) ?></td>
            <td><?= htmlspecialchars($d['mobile']) ?></td>
            <td><?= htmlspecialchars($d['vehicle_category_name'] ?? '—') ?></td>
            <td><?= htmlspecialchars($d['vehicle_number'] ?? '—') ?></td>
            <td><?= $d['is_available'] ? '<span class="badge bg-success">Online</span>' : '<span class="badge bg-secondary">Offline</span>' ?></td>
            <td><span class="badge bg-primary-subtle text-primary"><?= (int) $d['total_bookings'] ?></span></td>
            <td>
              <?php $badgeClass = ['active' => 'bg-success', 'inactive' => 'bg-secondary', 'blocked' => 'bg-danger'][$d['status']]; ?>
              <span class="badge <?= $badgeClass ?>"><?= ucfirst($d['status']) ?></span>
            </td>
            <td class="text-end">
              <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editModal"
                      onclick='openEdit(<?= json_encode($d) ?>)'><i class="bi bi-pencil"></i></button>
              <button class="btn btn-sm btn-outline-danger" onclick="confirmDelete(<?= (int) $d['id'] ?>, '<?= htmlspecialchars($d['name'], ENT_QUOTES) ?>')"><i class="bi bi-trash"></i></button>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="POST" action="drivers.php">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="editId">
      <div class="modal-header">
        <h5 class="modal-title">Edit Driver</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" id="editName" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" id="editEmail" class="form-control"></div>
        <div class="mb-3">
          <label class="form-label">Vehicle Category</label>
          <select name="vehicle_category_id" id="editVehicleCategory" class="form-select" required>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= (int) $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3"><label class="form-label">Vehicle Number</label><input type="text" name="vehicle_number" id="editVehicleNumber" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Driving License</label><input type="text" name="driving_license" id="editDrivingLicense" class="form-control"></div>
        <div class="mb-3">
          <label class="form-label">Status</label>
          <select name="status" id="editStatus" class="form-select">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="blocked">Blocked</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<form method="POST" action="drivers.php" id="deleteForm" class="d-none">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
  <input type="hidden" name="action" value="delete">
  <input type="hidden" name="id" id="deleteId">
</form>

<script>
function openEdit(d) {
  document.getElementById('editId').value = d.id;
  document.getElementById('editName').value = d.name;
  document.getElementById('editEmail').value = d.email || '';
  document.getElementById('editVehicleCategory').value = d.vehicle_category_id;
  document.getElementById('editVehicleNumber').value = d.vehicle_number || '';
  document.getElementById('editDrivingLicense').value = d.driving_license || '';
  document.getElementById('editStatus').value = d.status;
}
function confirmDelete(id, name) {
  if (confirm('Delete driver "' + name + '"? This cannot be undone.')) {
    document.getElementById('deleteId').value = id;
    document.getElementById('deleteForm').submit();
  }
}
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
