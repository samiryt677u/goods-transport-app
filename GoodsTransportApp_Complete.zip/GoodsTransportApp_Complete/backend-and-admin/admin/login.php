<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/auth_check.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        $error = 'Session expired, please try again.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username === '' || $password === '') {
            $error = 'Please enter both username and password.';
        } else {
            $pdo  = Database::getInstance()->getConnection();
            $stmt = $pdo->prepare('SELECT * FROM admin WHERE username = :username LIMIT 1');
            $stmt->execute(['username' => $username]);
            $admin = $stmt->fetch();

            if (!$admin || !password_verify($password, $admin['password'])) {
                $error = 'Invalid username or password.';
            } elseif ($admin['status'] !== 'active') {
                $error = 'This admin account is inactive.';
            } else {
                $_SESSION['admin_id']   = (int) $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];

                $upd = $pdo->prepare('UPDATE admin SET last_login = NOW() WHERE id = :id');
                $upd->execute(['id' => $admin['id']]);

                header('Location: dashboard.php');
                exit();
            }
        }
    }
}

$csrfToken = csrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login | Goods Transport Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  body { background: linear-gradient(135deg, #0d6efd 0%, #084298 100%); min-height: 100vh; display: flex; align-items: center; }
  .login-card { border-radius: 16px; border: none; box-shadow: 0 10px 40px rgba(0,0,0,0.2); }
</style>
</head>
<body>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-11 col-sm-8 col-md-5 col-lg-4">
      <div class="card login-card p-4">
        <div class="text-center mb-3">
          <i class="bi bi-truck" style="font-size: 2.5rem; color:#0d6efd;"></i>
          <h4 class="mt-2 mb-0">Goods Transport</h4>
          <small class="text-muted">Admin Panel Login</small>
        </div>

        <?php if ($error): ?>
          <div class="alert alert-danger py-2"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required autofocus
                   value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
      </div>
    </div>
  </div>
</div>
</body>
</html>
