# Goods Transport Booking App — Complete Project

Full-stack goods transport booking platform: Flutter app (Customer +
Driver) + Core PHP/MySQL REST API + Admin Panel.

## Folder Structure

```
backend-and-admin/     Core PHP + MySQL — REST API + Admin Panel
  api/                 REST endpoints consumed by the Flutter app
  admin/               Browser-based admin panel (Bootstrap 5)
  database/schema.sql  Full DB schema + seed data

flutter-app/           Single Flutter app — Customer & Driver
  lib/                 All Dart source
  README.md            Flutter-specific setup (Maps API key, Android config, etc.)
```

## Status

- **Backend + Admin Panel**: Complete and live-tested end-to-end against
  a real database (registration, login, full booking lifecycle
  including the accept race-condition guard, payments, and every admin
  page) — currently deployed at `demo.mytoolshub.co.in`.
- **Flutter App**: Complete Dart source for both Customer and Driver
  flows (auth, booking creation with Google Maps picker, accept/complete
  flow, payments, history, profile). Written and carefully self-reviewed
  (import resolution, brace balance, current Flutter API usage all
  verified) but **not yet compiled**, since this chat environment has no
  Flutter SDK available. See `flutter-app/README.md` for the exact steps
  to scaffold the native Android project and build it — the same
  GitHub Codespaces workflow used on your other apps.

## Quick Start

1. **Backend**: already deployed — DB credentials in
   `backend-and-admin/api/config/database.php` point at
   `demo.mytoolshub.co.in`. Admin login: `admin` / `Admin@123` (change
   this after first login).
2. **Flutter app**: open `flutter-app/` in Codespaces, run
   `flutter pub get`, then `flutter create .` to generate the native
   folders, then follow `flutter-app/README.md` steps 4a/4b for the Maps
   API key and permissions before building.
