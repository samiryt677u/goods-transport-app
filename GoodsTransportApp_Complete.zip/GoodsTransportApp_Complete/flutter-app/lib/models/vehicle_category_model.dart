class VehicleCategoryModel {
  final int id;
  final String name;
  final String? icon;
  final double baseFare;
  final double perKmRate;
  final String? capacity;

  VehicleCategoryModel({
    required this.id,
    required this.name,
    this.icon,
    required this.baseFare,
    required this.perKmRate,
    this.capacity,
  });

  factory VehicleCategoryModel.fromJson(Map<String, dynamic> json) {
    return VehicleCategoryModel(
      id: json['id'] is int ? json['id'] : int.parse(json['id'].toString()),
      name: json['name'] ?? '',
      icon: json['icon'],
      baseFare: double.tryParse(json['base_fare'].toString()) ?? 0.0,
      perKmRate: double.tryParse(json['per_km_rate'].toString()) ?? 0.0,
      capacity: json['capacity'],
    );
  }

  /// Local icon lookup — the icon strings from the DB (bike.png etc.) are
  /// just labels; the app maps them to Material icons so no image assets
  /// need to be bundled or downloaded.
  static const Map<String, String> _iconKeyByName = {
    'bike': 'bike',
    'auto': 'auto',
    'pickup': 'pickup',
    'mini truck': 'truck',
  };

  String get iconKey => _iconKeyByName[name.toLowerCase()] ?? 'truck';
}
