class UserModel {
  final int id;
  final String name;
  final String mobile;
  final String? email;
  final String role;
  final String? profileImage;
  final int? vehicleCategoryId;
  final String? vehicleCategoryName;
  final String? vehicleNumber;
  final String? drivingLicense;
  final bool isAvailable;
  final String status;

  UserModel({
    required this.id,
    required this.name,
    required this.mobile,
    this.email,
    required this.role,
    this.profileImage,
    this.vehicleCategoryId,
    this.vehicleCategoryName,
    this.vehicleNumber,
    this.drivingLicense,
    this.isAvailable = true,
    this.status = 'active',
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] is int ? json['id'] : int.parse(json['id'].toString()),
      name: json['name'] ?? '',
      mobile: json['mobile'] ?? '',
      email: json['email'],
      role: json['role'] ?? '',
      profileImage: json['profile_image'],
      vehicleCategoryId: json['vehicle_category_id'] == null
          ? null
          : int.tryParse(json['vehicle_category_id'].toString()),
      vehicleCategoryName: json['vehicle_category_name'],
      vehicleNumber: json['vehicle_number'],
      drivingLicense: json['driving_license'],
      isAvailable: json['is_available'] is bool
          ? json['is_available']
          : (json['is_available'] == 1 || json['is_available'] == '1'),
      status: json['status'] ?? 'active',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'mobile': mobile,
      'email': email,
      'role': role,
      'profile_image': profileImage,
      'vehicle_category_id': vehicleCategoryId,
      'vehicle_category_name': vehicleCategoryName,
      'vehicle_number': vehicleNumber,
      'driving_license': drivingLicense,
      'is_available': isAvailable,
      'status': status,
    };
  }

  UserModel copyWith({
    String? name,
    String? email,
    String? vehicleNumber,
    String? drivingLicense,
    bool? isAvailable,
  }) {
    return UserModel(
      id: id,
      name: name ?? this.name,
      mobile: mobile,
      email: email ?? this.email,
      role: role,
      profileImage: profileImage,
      vehicleCategoryId: vehicleCategoryId,
      vehicleCategoryName: vehicleCategoryName,
      vehicleNumber: vehicleNumber ?? this.vehicleNumber,
      drivingLicense: drivingLicense ?? this.drivingLicense,
      isAvailable: isAvailable ?? this.isAvailable,
      status: status,
    );
  }
}
