/// Represents a booking. Different endpoints (create / pending / history /
/// details) return different subsets of these fields, so every field
/// except the handful that are always present is nullable. `fromJson` is
/// defensive about that on purpose.
class BookingModel {
  final int id;
  final String bookingCode;
  final String status;
  final int? customerId;
  final int? driverId;
  final int? vehicleCategoryId;
  final String? vehicleCategoryName;

  final String pickupAddress;
  final double? pickupLat;
  final double? pickupLng;
  final String deliveryAddress;
  final double? deliveryLat;
  final double? deliveryLng;

  final double distanceKm;
  final double estimatedFare;
  final double? finalFare;
  final String? goodsDescription;
  final String? cancelReason;

  final String? customerName;
  final String? customerMobile;
  final String? driverName;
  final String? driverMobile;
  final String? driverVehicleNumber;

  final String? paymentMode;
  final String? paymentStatus;
  final double? paymentAmount;

  final String? createdAt;
  final String? acceptedAt;
  final String? completedAt;

  BookingModel({
    required this.id,
    required this.bookingCode,
    required this.status,
    this.customerId,
    this.driverId,
    this.vehicleCategoryId,
    this.vehicleCategoryName,
    required this.pickupAddress,
    this.pickupLat,
    this.pickupLng,
    required this.deliveryAddress,
    this.deliveryLat,
    this.deliveryLng,
    required this.distanceKm,
    required this.estimatedFare,
    this.finalFare,
    this.goodsDescription,
    this.cancelReason,
    this.customerName,
    this.customerMobile,
    this.driverName,
    this.driverMobile,
    this.driverVehicleNumber,
    this.paymentMode,
    this.paymentStatus,
    this.paymentAmount,
    this.createdAt,
    this.acceptedAt,
    this.completedAt,
  });

  static double? _toDouble(dynamic v) {
    if (v == null) return null;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString());
  }

  static int? _toInt(dynamic v) {
    if (v == null) return null;
    if (v is int) return v;
    return int.tryParse(v.toString());
  }

  factory BookingModel.fromJson(Map<String, dynamic> json) {
    return BookingModel(
      id: _toInt(json['id'] ?? json['booking_id']) ?? 0,
      bookingCode: json['booking_code'] ?? '',
      status: json['status'] ?? 'pending',
      customerId: _toInt(json['customer_id']),
      driverId: _toInt(json['driver_id']),
      vehicleCategoryId: _toInt(json['vehicle_category_id']),
      vehicleCategoryName:
          json['vehicle_category_name'] ?? json['vehicle_category'],
      pickupAddress: json['pickup_address'] ?? '',
      pickupLat: _toDouble(json['pickup_lat']),
      pickupLng: _toDouble(json['pickup_lng']),
      deliveryAddress: json['delivery_address'] ?? '',
      deliveryLat: _toDouble(json['delivery_lat']),
      deliveryLng: _toDouble(json['delivery_lng']),
      distanceKm: _toDouble(json['distance_km']) ?? 0.0,
      estimatedFare: _toDouble(json['estimated_fare']) ?? 0.0,
      finalFare: _toDouble(json['final_fare']),
      goodsDescription: json['goods_description'],
      cancelReason: json['cancel_reason'],
      customerName: json['customer_name'],
      customerMobile: json['customer_mobile'],
      driverName: json['driver_name'],
      driverMobile: json['driver_mobile'],
      driverVehicleNumber: json['vehicle_number'],
      paymentMode: json['payment_mode'],
      paymentStatus: json['payment_status'],
      paymentAmount: _toDouble(json['payment_amount']),
      createdAt: json['created_at'],
      acceptedAt: json['accepted_at'],
      completedAt: json['completed_at'],
    );
  }

  /// The fare to display to the user: final fare once completed,
  /// otherwise the server-calculated estimate.
  double get displayFare => finalFare ?? estimatedFare;

  bool get isPending => status == 'pending';
  bool get isAccepted => status == 'accepted';
  bool get isCompleted => status == 'completed';
  bool get isCancelled => status == 'cancelled';

  bool get isCash => paymentMode == 'cash';
  bool get isPaid => paymentStatus == 'paid';
}
