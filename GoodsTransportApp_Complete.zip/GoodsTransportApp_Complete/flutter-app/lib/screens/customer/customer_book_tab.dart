import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../models/booking_model.dart';
import '../../providers/booking_provider.dart';
import '../../widgets/loading_widgets.dart';
import '../../widgets/status_badge.dart';
import '../shared/booking_detail_screen.dart';
import '../shared/location_picker_screen.dart';

class CustomerBookTab extends StatefulWidget {
  const CustomerBookTab({super.key});

  @override
  State<CustomerBookTab> createState() => _CustomerBookTabState();
}

class _CustomerBookTabState extends State<CustomerBookTab> {
  final _goodsController = TextEditingController();

  PickedLocation? _pickup;
  PickedLocation? _delivery;
  int? _selectedCategoryId;
  String _paymentMode = PaymentMode.cash;
  bool _loadingInitial = true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final provider = context.read<BookingProvider>();
    await Future.wait([
      provider.loadCategories(),
      provider.refreshActiveBooking(),
    ]);
    if (mounted) setState(() => _loadingInitial = false);
  }

  @override
  void dispose() {
    _goodsController.dispose();
    super.dispose();
  }

  Future<void> _pickPickup() async {
    final result = await Navigator.of(context).push<PickedLocation>(
      MaterialPageRoute(
        builder: (_) => LocationPickerScreen(
          title: 'Select Pickup Location',
          initialLat: _pickup?.lat,
          initialLng: _pickup?.lng,
        ),
      ),
    );
    if (result != null) setState(() => _pickup = result);
  }

  Future<void> _pickDelivery() async {
    final result = await Navigator.of(context).push<PickedLocation>(
      MaterialPageRoute(
        builder: (_) => LocationPickerScreen(
          title: 'Select Delivery Location',
          initialLat: _delivery?.lat ?? _pickup?.lat,
          initialLng: _delivery?.lng ?? _pickup?.lng,
        ),
      ),
    );
    if (result != null) setState(() => _delivery = result);
  }

  Future<void> _book() async {
    if (_pickup == null || _delivery == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select both pickup and delivery locations')),
      );
      return;
    }
    if (_selectedCategoryId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a vehicle category')),
      );
      return;
    }

    final provider = context.read<BookingProvider>();
    final result = await provider.createBooking(
      vehicleCategoryId: _selectedCategoryId!,
      pickupAddress: _pickup!.address,
      pickupLat: _pickup!.lat,
      pickupLng: _pickup!.lng,
      deliveryAddress: _delivery!.address,
      deliveryLat: _delivery!.lat,
      deliveryLng: _delivery!.lng,
      goodsDescription: _goodsController.text.trim(),
      paymentMode: _paymentMode,
    );

    if (!mounted) return;
    if (result != null) {
      setState(() {
        _pickup = null;
        _delivery = null;
        _selectedCategoryId = null;
        _goodsController.clear();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Booking ${result['booking_code']} created!')),
      );
    } else if (provider.errorMessage != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(provider.errorMessage!)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<BookingProvider>();

    if (_loadingInitial) {
      return const Scaffold(body: LoadingView());
    }

    if (provider.activeBooking != null) {
      return _ActiveBookingView(
        booking: provider.activeBooking!,
        onRefresh: () => context.read<BookingProvider>().refreshActiveBooking(),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Book a Vehicle')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (provider.errorMessage != null)
              ErrorBanner(message: provider.errorMessage!, onDismiss: provider.clearError),

            const Text('Pickup & Delivery', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            _LocationButton(
              icon: Icons.circle_outlined,
              color: AppColors.completed,
              label: _pickup?.address ?? 'Select pickup location',
              filled: _pickup != null,
              onTap: _pickPickup,
            ),
            const SizedBox(height: 10),
            _LocationButton(
              icon: Icons.location_on_outlined,
              color: AppColors.cancelled,
              label: _delivery?.address ?? 'Select delivery location',
              filled: _delivery != null,
              onTap: _pickDelivery,
            ),

            const SizedBox(height: 24),
            const Text('Vehicle Category', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            provider.categories.isEmpty
                ? const Padding(padding: EdgeInsets.symmetric(vertical: 20), child: LoadingView())
                : SizedBox(
                    height: 96,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: provider.categories.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 10),
                      itemBuilder: (context, index) {
                        final c = provider.categories[index];
                        final selected = _selectedCategoryId == c.id;
                        return GestureDetector(
                          onTap: () => setState(() => _selectedCategoryId = c.id),
                          child: Container(
                            width: 100,
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: selected ? AppColors.primary.withValues(alpha: 0.1) : AppColors.surface,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  _categoryIcon(c.iconKey),
                                  color: selected ? AppColors.primary : AppColors.textSecondary,
                                  size: 26,
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  c.name,
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w600,
                                    color: selected ? AppColors.primary : AppColors.textPrimary,
                                  ),
                                ),
                                Text(
                                  '₹${c.baseFare.toStringAsFixed(0)}+',
                                  style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),

            const SizedBox(height: 24),
            const Text('Goods Description (optional)', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            TextField(
              controller: _goodsController,
              maxLines: 2,
              decoration: const InputDecoration(hintText: 'e.g. 3 boxes of furniture'),
            ),

            const SizedBox(height: 24),
            const Text('Payment Mode', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _PaymentOption(
                    icon: Icons.money,
                    label: 'Cash',
                    selected: _paymentMode == PaymentMode.cash,
                    onTap: () => setState(() => _paymentMode = PaymentMode.cash),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _PaymentOption(
                    icon: Icons.account_balance_wallet_outlined,
                    label: 'Online',
                    selected: _paymentMode == PaymentMode.online,
                    onTap: () => setState(() => _paymentMode = PaymentMode.online),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 28),
            ElevatedButton(
              onPressed: provider.isSubmitting ? null : _book,
              child: provider.isSubmitting
                  ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.4))
                  : const Text('Book Vehicle'),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  IconData _categoryIcon(String key) {
    switch (key) {
      case 'bike':
        return Icons.two_wheeler;
      case 'auto':
        return Icons.electric_rickshaw;
      case 'pickup':
        return Icons.local_shipping_outlined;
      default:
        return Icons.fire_truck_outlined;
    }
  }
}

class _LocationButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final bool filled;
  final VoidCallback onTap;

  const _LocationButton({
    required this.icon,
    required this.color,
    required this.label,
    required this.filled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.border),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: filled ? AppColors.textPrimary : AppColors.textSecondary,
                  fontWeight: filled ? FontWeight.w600 : FontWeight.normal,
                  fontSize: 14,
                ),
              ),
            ),
            const Icon(Icons.chevron_right, color: AppColors.textSecondary),
          ],
        ),
      ),
    );
  }
}

class _PaymentOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _PaymentOption({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary.withValues(alpha: 0.1) : AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
        ),
        child: Column(
          children: [
            Icon(icon, color: selected ? AppColors.primary : AppColors.textSecondary),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: selected ? AppColors.primary : AppColors.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Shown instead of the booking form whenever the customer already has
/// a pending or accepted booking in flight.
class _ActiveBookingView extends StatelessWidget {
  final BookingModel booking;
  final Future<void> Function() onRefresh;
  const _ActiveBookingView({required this.booking, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Active Booking')),
      body: RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(booking.bookingCode, style: const TextStyle(fontWeight: FontWeight.w700)),
                        StatusBadge(status: booking.status),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Center(
                      child: Icon(
                        booking.isPending ? Icons.hourglass_top_rounded : Icons.local_shipping_rounded,
                        size: 48,
                        color: AppColors.primary,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Center(
                      child: Text(
                        booking.isPending
                            ? 'Looking for a nearby driver...'
                            : 'Your driver is on the way',
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Center(
                      child: Text(
                        booking.isPending
                            ? "We'll notify you once a driver accepts"
                            : '${booking.driverName ?? 'Driver'} • ${booking.driverMobile ?? ''}',
                        style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 20),
                    OutlinedButton(
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => BookingDetailScreen(bookingId: booking.id)),
                        );
                      },
                      child: const Text('View Details'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Center(
              child: Text(
                'Pull down to refresh status',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 12.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
