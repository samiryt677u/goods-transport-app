import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../models/booking_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/booking_provider.dart';
import '../../widgets/loading_widgets.dart';
import '../../widgets/status_badge.dart';

/// The API returns MySQL datetimes like "2026-08-05 14:30:00" — this
/// formats them into something readable without pulling in a full
/// date-picker dependency just for display.
String _formatDateTime(String? raw) {
  if (raw == null || raw.isEmpty) return '—';
  try {
    final dt = DateTime.parse(raw.replaceFirst(' ', 'T'));
    return DateFormat('d MMM, h:mm a').format(dt);
  } catch (_) {
    return raw;
  }
}

class BookingDetailScreen extends StatefulWidget {
  final int bookingId;
  const BookingDetailScreen({super.key, required this.bookingId});

  @override
  State<BookingDetailScreen> createState() => _BookingDetailScreenState();
}

class _BookingDetailScreenState extends State<BookingDetailScreen> {
  BookingModel? _booking;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final booking = await context.read<BookingProvider>().fetchDetails(widget.bookingId);
    if (!mounted) return;
    setState(() {
      _booking = booking;
      _loading = false;
    });
  }

  Future<void> _markCompleted() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Mark as Completed'),
        content: const Text('Confirm that the goods have been delivered?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirm')),
        ],
      ),
    );
    if (confirmed != true) return;
    if (!mounted) return;

    final provider = context.read<BookingProvider>();
    final success = await provider.completeBooking(widget.bookingId);
    if (!mounted) return;
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Delivery marked as completed')));
      _load();
    } else if (provider.errorMessage != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(provider.errorMessage!)));
    }
  }

  Future<void> _confirmPayment() async {
    final provider = context.read<BookingProvider>();
    final success = await provider.confirmPayment(widget.bookingId, success: true);
    if (!mounted) return;
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Payment confirmed')));
      _load();
    } else if (provider.errorMessage != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(provider.errorMessage!)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final provider = context.watch<BookingProvider>();
    final booking = _booking;

    return Scaffold(
      appBar: AppBar(title: Text(booking?.bookingCode ?? 'Booking Details')),
      body: _loading
          ? const LoadingView()
          : booking == null
              ? const EmptyStateView(icon: Icons.error_outline, title: 'Could not load booking')
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.all(20),
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(booking.bookingCode, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                          StatusBadge(status: booking.status),
                        ],
                      ),
                      const SizedBox(height: 20),

                      _SectionCard(
                        children: [
                          _LocationTile(
                            icon: Icons.circle, color: AppColors.completed,
                            label: 'Pickup', address: booking.pickupAddress,
                          ),
                          const Padding(
                            padding: EdgeInsets.only(left: 7),
                            child: SizedBox(height: 18, child: VerticalDivider(thickness: 1.5)),
                          ),
                          _LocationTile(
                            icon: Icons.location_on, color: AppColors.cancelled,
                            label: 'Delivery', address: booking.deliveryAddress,
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),

                      _SectionCard(
                        children: [
                          _InfoRow(label: 'Vehicle Category', value: booking.vehicleCategoryName ?? '—'),
                          _InfoRow(label: 'Distance', value: '${booking.distanceKm.toStringAsFixed(1)} km'),
                          _InfoRow(label: 'Fare', value: '₹${booking.displayFare.toStringAsFixed(2)}'),
                          if (booking.goodsDescription != null && booking.goodsDescription!.isNotEmpty)
                            _InfoRow(label: 'Goods', value: booking.goodsDescription!),
                        ],
                      ),
                      const SizedBox(height: 14),

                      _SectionCard(
                        children: [
                          _InfoRow(label: 'Booked On', value: _formatDateTime(booking.createdAt)),
                          if (booking.acceptedAt != null)
                            _InfoRow(label: 'Accepted On', value: _formatDateTime(booking.acceptedAt)),
                          if (booking.completedAt != null)
                            _InfoRow(label: 'Completed On', value: _formatDateTime(booking.completedAt)),
                        ],
                      ),
                      const SizedBox(height: 14),

                      if (auth.isDriver && booking.customerName != null)
                        _SectionCard(children: [
                          _InfoRow(label: 'Customer', value: booking.customerName!),
                          if (booking.customerMobile != null)
                            _InfoRow(label: 'Mobile', value: booking.customerMobile!),
                        ]),
                      if (auth.isCustomer && booking.driverName != null)
                        _SectionCard(children: [
                          _InfoRow(label: 'Driver', value: booking.driverName!),
                          if (booking.driverMobile != null)
                            _InfoRow(label: 'Mobile', value: booking.driverMobile!),
                          if (booking.driverVehicleNumber != null)
                            _InfoRow(label: 'Vehicle No.', value: booking.driverVehicleNumber!),
                        ]),
                      const SizedBox(height: 14),

                      if (booking.paymentMode != null)
                        _SectionCard(children: [
                          _InfoRow(label: 'Payment Mode', value: booking.paymentMode == PaymentMode.cash ? 'Cash' : 'Online'),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Payment Status', style: TextStyle(color: AppColors.textSecondary, fontSize: 13.5)),
                              StatusBadge(status: booking.paymentStatus ?? 'pending'),
                            ],
                          ),
                        ]),

                      const SizedBox(height: 24),

                      if (provider.errorMessage != null)
                        ErrorBanner(message: provider.errorMessage!, onDismiss: provider.clearError),

                      // ---- Driver: mark delivered ----
                      if (auth.isDriver && booking.isAccepted && booking.driverId == auth.user?.id)
                        ElevatedButton.icon(
                          onPressed: provider.isSubmitting ? null : _markCompleted,
                          icon: const Icon(Icons.check_circle_outline),
                          label: const Text('Mark as Completed'),
                        ),

                      // ---- Cash: driver confirms collection ----
                      if (auth.isDriver &&
                          booking.isCompleted &&
                          booking.isCash &&
                          !booking.isPaid &&
                          booking.driverId == auth.user?.id)
                        ElevatedButton.icon(
                          onPressed: provider.isSubmitting ? null : _confirmPayment,
                          icon: const Icon(Icons.payments_outlined),
                          label: const Text('Confirm Cash Received'),
                        ),

                      // ---- Online: customer confirms payment ----
                      if (auth.isCustomer &&
                          booking.isCompleted &&
                          !booking.isCash &&
                          !booking.isPaid &&
                          booking.customerId == auth.user?.id)
                        ElevatedButton.icon(
                          onPressed: provider.isSubmitting ? null : _confirmPayment,
                          icon: const Icon(Icons.payment),
                          label: const Text('Pay Now'),
                        ),

                      if (booking.isCompleted && booking.isPaid)
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: AppColors.completed.withValues(alpha: 0.08),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Row(
                            children: [
                              Icon(Icons.check_circle, color: AppColors.completed, size: 20),
                              SizedBox(width: 10),
                              Text('Payment received. Trip complete!', style: TextStyle(color: AppColors.completed, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final List<Widget> children;
  const _SectionCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
      ),
    );
  }
}

class _LocationTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final String address;
  const _LocationTile({required this.icon, required this.color, required this.label, required this.address});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(padding: const EdgeInsets.only(top: 2), child: Icon(icon, size: 14, color: color)),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              Text(address, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w500)),
            ],
          ),
        ),
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13.5)),
          Flexible(
            child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
          ),
        ],
      ),
    );
  }
}
