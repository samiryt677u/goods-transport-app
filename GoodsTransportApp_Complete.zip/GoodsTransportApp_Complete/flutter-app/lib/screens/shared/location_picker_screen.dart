import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../services/location_service.dart';

class PickedLocation {
  final double lat;
  final double lng;
  final String address;
  PickedLocation({required this.lat, required this.lng, required this.address});
}

/// Full-screen map picker. The marker sits fixed at the center of the
/// screen; the user pans the map underneath it (the classic Uber/Ola
/// pattern) or searches by name. On confirm, the current center is
/// reverse-geocoded into an address and returned to the caller.
class LocationPickerScreen extends StatefulWidget {
  final String title;
  final double? initialLat;
  final double? initialLng;

  const LocationPickerScreen({
    super.key,
    required this.title,
    this.initialLat,
    this.initialLng,
  });

  @override
  State<LocationPickerScreen> createState() => _LocationPickerScreenState();
}

class _LocationPickerScreenState extends State<LocationPickerScreen> {
  final _locationService = LocationService();
  final _searchController = TextEditingController();
  GoogleMapController? _mapController;

  late LatLng _center;
  String _address = 'Move the map to select location';
  bool _resolvingAddress = false;
  bool _locating = false;
  bool _searching = false;

  @override
  void initState() {
    super.initState();
    _center = LatLng(
      widget.initialLat ?? AppConstants.defaultLat,
      widget.initialLng ?? AppConstants.defaultLng,
    );
    if (widget.initialLat != null) {
      _resolveAddress(_center);
    } else {
      _useCurrentLocation();
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _resolveAddress(LatLng position) async {
    setState(() => _resolvingAddress = true);
    final address = await _locationService.reverseGeocode(position.latitude, position.longitude);
    if (!mounted) return;
    setState(() {
      _address = address;
      _resolvingAddress = false;
    });
  }

  Future<void> _useCurrentLocation() async {
    setState(() => _locating = true);
    try {
      final position = await _locationService.getCurrentPosition();
      final target = LatLng(position.latitude, position.longitude);
      _mapController?.animateCamera(CameraUpdate.newLatLngZoom(target, 16));
      setState(() => _center = target);
      await _resolveAddress(target);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _searchAddress() async {
    final query = _searchController.text.trim();
    if (query.isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() => _searching = true);
    final result = await _locationService.searchAddress(query);
    if (!mounted) return;
    setState(() => _searching = false);
    if (result == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Location not found. Try a different search.')),
      );
      return;
    }
    final target = LatLng(result.lat, result.lng);
    _mapController?.animateCamera(CameraUpdate.newLatLngZoom(target, 16));
    setState(() {
      _center = target;
      _address = result.address;
    });
  }

  void _confirm() {
    Navigator.of(context).pop(
      PickedLocation(lat: _center.latitude, lng: _center.longitude, address: _address),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(target: _center, zoom: 15),
            onMapCreated: (controller) => _mapController = controller,
            onCameraMove: (position) => _center = position.target,
            onCameraIdle: () => _resolveAddress(_center),
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
          ),
          // Fixed center marker
          const IgnorePointer(
            child: Center(
              child: Padding(
                padding: EdgeInsets.only(bottom: 40),
                child: Icon(Icons.location_on, size: 44, color: AppColors.primary),
              ),
            ),
          ),
          // Search bar
          Positioned(
            top: 12, left: 12, right: 12,
            child: Material(
              elevation: 3,
              borderRadius: BorderRadius.circular(12),
              child: TextField(
                controller: _searchController,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _searchAddress(),
                decoration: InputDecoration(
                  hintText: 'Search for area, street name...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                  filled: true,
                  fillColor: Colors.white,
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _searching
                      ? const Padding(
                          padding: EdgeInsets.all(14),
                          child: SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                        )
                      : IconButton(icon: const Icon(Icons.my_location), onPressed: _useCurrentLocation),
                ),
              ),
            ),
          ),
          if (_locating)
            Container(
              color: Colors.black.withValues(alpha: 0.2),
              child: const Center(child: CircularProgressIndicator()),
            ),
          // Bottom confirm card
          Positioned(
            left: 0, right: 0, bottom: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 20),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 12, offset: Offset(0, -3))],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.location_on, color: AppColors.primary, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _resolvingAddress
                            ? const Text('Locating address...', style: TextStyle(color: AppColors.textSecondary))
                            : Text(
                                _address,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14.5),
                              ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  ElevatedButton(
                    onPressed: _resolvingAddress ? null : _confirm,
                    child: const Text('Confirm Location'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
