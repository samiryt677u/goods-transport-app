import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/loading_widgets.dart';
import '../auth/role_select_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _vehicleNumberController = TextEditingController();
  final _licenseController = TextEditingController();

  final _passwordFormKey = GlobalKey<FormState>();
  final _currentPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  bool _showPasswordFields = false;
  bool _editingDetails = false;

  @override
  void initState() {
    super.initState();
    _loadFromUser();
  }

  void _loadFromUser() {
    final user = context.read<AuthProvider>().user;
    if (user == null) return;
    _nameController.text = user.name;
    _emailController.text = user.email ?? '';
    _vehicleNumberController.text = user.vehicleNumber ?? '';
    _licenseController.text = user.drivingLicense ?? '';
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _vehicleNumberController.dispose();
    _licenseController.dispose();
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    super.dispose();
  }

  Future<void> _saveDetails() async {
    final auth = context.read<AuthProvider>();
    final success = await auth.updateProfile(
      name: _nameController.text.trim(),
      email: _emailController.text.trim(),
      vehicleNumber: auth.isDriver ? _vehicleNumberController.text.trim() : null,
      drivingLicense: auth.isDriver ? _licenseController.text.trim() : null,
    );
    if (!mounted) return;
    if (success) {
      setState(() => _editingDetails = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile updated')));
    }
  }

  Future<void> _changePassword() async {
    if (!_passwordFormKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final success = await auth.updateProfile(
      currentPassword: _currentPasswordController.text,
      newPassword: _newPasswordController.text,
    );
    if (!mounted) return;
    if (success) {
      _currentPasswordController.clear();
      _newPasswordController.clear();
      setState(() => _showPasswordFields = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Password changed')));
    }
  }

  Future<void> _toggleAvailability(bool value) async {
    await context.read<AuthProvider>().updateProfile(isAvailable: value);
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Logout')),
        ],
      ),
    );
    if (confirmed != true) return;
    if (!mounted) return;
    await context.read<AuthProvider>().logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const RoleSelectScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.user;

    if (user == null) return const LoadingView();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          IconButton(
            icon: Icon(_editingDetails ? Icons.close : Icons.edit_outlined),
            onPressed: () => setState(() {
              if (_editingDetails) _loadFromUser();
              _editingDetails = !_editingDetails;
            }),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: AppColors.primary.withValues(alpha: 0.1),
                    child: Text(
                      user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                      style: const TextStyle(fontSize: 30, color: AppColors.primary, fontWeight: FontWeight.w700),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(user.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  Text(user.mobile, style: const TextStyle(color: AppColors.textSecondary)),
                ],
              ),
            ),
            const SizedBox(height: 24),

            if (auth.isDriver) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      const Icon(Icons.wifi_tethering, color: AppColors.primary),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text('Available for new bookings', style: TextStyle(fontWeight: FontWeight.w600)),
                      ),
                      Switch(value: user.isAvailable, onChanged: auth.isLoading ? null : _toggleAvailability),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],

            if (auth.errorMessage != null)
              ErrorBanner(message: auth.errorMessage!, onDismiss: auth.clearError),

            const Text('Account Details', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            TextFormField(
              controller: _nameController,
              enabled: _editingDetails,
              decoration: const InputDecoration(labelText: 'Full Name', prefixIcon: Icon(Icons.person_outline)),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _emailController,
              enabled: _editingDetails,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined)),
            ),

            if (auth.isDriver) ...[
              const SizedBox(height: 12),
              TextFormField(
                enabled: false,
                initialValue: user.vehicleCategoryName ?? '—',
                decoration: const InputDecoration(
                  labelText: 'Vehicle Category', prefixIcon: Icon(Icons.local_shipping_outlined),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _vehicleNumberController,
                enabled: _editingDetails,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(labelText: 'Vehicle Number', prefixIcon: Icon(Icons.pin_outlined)),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _licenseController,
                enabled: _editingDetails,
                decoration: const InputDecoration(labelText: 'Driving License', prefixIcon: Icon(Icons.badge_outlined)),
              ),
            ],

            if (_editingDetails) ...[
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: auth.isLoading ? null : _saveDetails,
                child: auth.isLoading
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('Save Changes'),
              ),
            ],

            const SizedBox(height: 28),
            InkWell(
              onTap: () => setState(() => _showPasswordFields = !_showPasswordFields),
              child: Row(
                children: [
                  const Text('Change Password', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Icon(_showPasswordFields ? Icons.expand_less : Icons.expand_more),
                ],
              ),
            ),
            if (_showPasswordFields) ...[
              const SizedBox(height: 12),
              Form(
                key: _passwordFormKey,
                child: Column(
                  children: [
                    TextFormField(
                      controller: _currentPasswordController,
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'Current Password'),
                      validator: (v) => (v == null || v.isEmpty) ? 'Required' : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _newPasswordController,
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'New Password'),
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'Required';
                        if (v.length < 6) return 'Minimum 6 characters';
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton(onPressed: _changePassword, child: const Text('Update Password')),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 32),
            OutlinedButton.icon(
              onPressed: _logout,
              icon: const Icon(Icons.logout, color: AppColors.cancelled),
              label: const Text('Logout', style: TextStyle(color: AppColors.cancelled)),
              style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.cancelled)),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
