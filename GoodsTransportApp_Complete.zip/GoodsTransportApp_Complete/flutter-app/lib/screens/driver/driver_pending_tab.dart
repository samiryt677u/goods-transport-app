import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme.dart';
import '../../models/booking_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/booking_provider.dart';
import '../../widgets/booking_card.dart';
import '../../widgets/loading_widgets.dart';
import '../../widgets/status_badge.dart';
import '../shared/booking_detail_screen.dart';

class DriverPendingTab extends StatefulWidget {
  const DriverPendingTab({super.key});

  @override
  State<DriverPendingTab> createState() => _DriverPendingTabState();
}

class _DriverPendingTabState extends State<DriverPendingTab> {
  bool _loadingInitial = true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _refresh();
    if (mounted) setState(() => _loadingInitial = false);
  }

  Future<void> _refresh() async {
    final provider = context.read<BookingProvider>();
    await provider.refreshActiveBooking();
    if (provider.activeBooking == null) {
      await provider.loadPending();
    }
  }

  Future<void> _accept(int bookingId) async {
    final provider = context.read<BookingProvider>();
    final success = await provider.acceptBooking(bookingId);
    if (!mounted) return;
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Booking accepted!')));
    } else if (provider.errorMessage != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(provider.errorMessage!)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<BookingProvider>();
    final auth = context.watch<AuthProvider>();

    if (_loadingInitial) {
      return const Scaffold(body: LoadingView());
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        actions: [
          if (auth.user != null)
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Center(
                child: Row(
                  children: [
                    Container(
                      width: 8, height: 8,
                      decoration: BoxDecoration(
                        color: auth.user!.isAvailable ? AppColors.completed : AppColors.textSecondary,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      auth.user!.isAvailable ? 'Online' : 'Offline',
                      style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
      body: provider.activeBooking != null
          ? _ActiveJobView(booking: provider.activeBooking!, onRefresh: _refresh)
          : RefreshIndicator(
              onRefresh: _refresh,
              child: provider.isLoading
                  ? const LoadingView()
                  : provider.pendingBookings.isEmpty
                      ? ListView(
                          children: const [
                            SizedBox(height: 100),
                            EmptyStateView(
                              icon: Icons.inbox_outlined,
                              title: 'No bookings right now',
                              subtitle: 'Pull down to check for new bookings\nin your vehicle category',
                            ),
                          ],
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: provider.pendingBookings.length,
                          itemBuilder: (context, index) {
                            final booking = provider.pendingBookings[index];
                            return BookingCard(
                              booking: booking,
                              trailingAction: SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: provider.isSubmitting ? null : () => _accept(booking.id),
                                  child: const Text('Accept'),
                                ),
                              ),
                            );
                          },
                        ),
            ),
    );
  }
}

/// Shown instead of the pending list once the driver has an accepted
/// job in progress — a driver handles one delivery at a time.
class _ActiveJobView extends StatelessWidget {
  final BookingModel booking;
  final Future<void> Function() onRefresh;
  const _ActiveJobView({required this.booking, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(booking.bookingCode, style: const TextStyle(fontWeight: FontWeight.w700)),
                      StatusBadge(status: booking.status),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Center(child: Icon(Icons.local_shipping_rounded, size: 48, color: AppColors.primary)),
                  const SizedBox(height: 12),
                  const Center(
                    child: Text('Delivery in progress', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(height: 4),
                  Center(
                    child: Text(
                      '${booking.customerName ?? 'Customer'} • ${booking.customerMobile ?? ''}',
                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => BookingDetailScreen(bookingId: booking.id)),
                      );
                    },
                    child: const Text('View Details & Complete'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Center(
            child: Text('Pull down to refresh', style: TextStyle(color: AppColors.textSecondary, fontSize: 12.5)),
          ),
        ],
      ),
    );
  }
}
