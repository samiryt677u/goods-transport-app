/// App-wide constants.
///
/// IMPORTANT: Update [ApiConstants.baseUrl] to your deployed domain
/// before building the release APK. For local testing against an
/// Android emulator hitting your own machine, use 10.0.2.2 instead
/// of localhost.
class ApiConstants {
  static const String baseUrl = 'https://demo.mytoolshub.co.in/api';

  // ---- Auth ----
  static const String register = '$baseUrl/auth/register.php';
  static const String login = '$baseUrl/auth/login.php';
  static const String logout = '$baseUrl/auth/logout.php';

  // ---- Profile ----
  static const String profileGet = '$baseUrl/profile/get.php';
  static const String profileUpdate = '$baseUrl/profile/update.php';

  // ---- Vehicle categories ----
  static const String vehicleCategories = '$baseUrl/vehicle_categories/list.php';

  // ---- Bookings ----
  static const String bookingCreate = '$baseUrl/bookings/create.php';
  static const String bookingPending = '$baseUrl/bookings/pending.php';
  static const String bookingAccept = '$baseUrl/bookings/accept.php';
  static const String bookingComplete = '$baseUrl/bookings/complete.php';
  static const String bookingHistory = '$baseUrl/bookings/history.php';
  static const String bookingDetails = '$baseUrl/bookings/details.php';

  // ---- Payments ----
  static const String paymentUpdate = '$baseUrl/payments/update.php';

  static const Duration requestTimeout = Duration(seconds: 15);
}

class AppConstants {
  static const String appName = 'Goods Transport';
  static const String prefKeyToken = 'auth_token';
  static const String prefKeyUser = 'auth_user';
  static const String prefKeyRole = 'auth_role';

  // Default map camera position (Patna) shown before GPS lock is acquired.
  static const double defaultLat = 25.5941;
  static const double defaultLng = 85.1376;
}

class UserRole {
  static const String customer = 'customer';
  static const String driver = 'driver';
}

class BookingStatus {
  static const String pending = 'pending';
  static const String accepted = 'accepted';
  static const String completed = 'completed';
  static const String cancelled = 'cancelled';
}

class PaymentMode {
  static const String cash = 'cash';
  static const String online = 'online';
}

class PaymentStatus {
  static const String pending = 'pending';
  static const String paid = 'paid';
  static const String failed = 'failed';
}
