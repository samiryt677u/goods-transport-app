import 'package:flutter/foundation.dart';
import '../core/constants.dart';
import '../models/booking_model.dart';
import '../models/vehicle_category_model.dart';
import '../services/booking_service.dart';
import '../services/payment_service.dart';
import '../services/vehicle_category_service.dart';

class BookingProvider extends ChangeNotifier {
  final BookingService _bookingService;
  final VehicleCategoryService _categoryService;
  final PaymentService _paymentService;

  BookingProvider(this._bookingService, this._categoryService, this._paymentService);

  List<VehicleCategoryModel> categories = [];
  List<BookingModel> pendingBookings = [];
  List<BookingModel> historyBookings = [];

  /// The single in-progress booking for the current user (status
  /// pending/accepted), if any. Both the customer "Book" tab and the
  /// driver "Home" tab use this to decide whether to show an active-job
  /// tracker or the normal booking/pending-list UI.
  BookingModel? activeBooking;

  bool isLoading = false;
  bool isSubmitting = false;
  String? errorMessage;

  Future<void> loadCategories() async {
    try {
      categories = await _categoryService.list();
      notifyListeners();
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      notifyListeners();
    }
  }

  /// Looks through the user's full history for a booking that's still
  /// pending or accepted. History is already sorted newest-first by the
  /// API, so the first match is the current one.
  Future<void> refreshActiveBooking() async {
    try {
      final all = await _bookingService.history();
      activeBooking = all.firstWhere(
        (b) => b.isPending || b.isAccepted,
        orElse: () => BookingModel(
          id: 0,
          bookingCode: '',
          status: 'none',
          pickupAddress: '',
          deliveryAddress: '',
          distanceKm: 0,
          estimatedFare: 0,
        ),
      );
      if (activeBooking!.id == 0) activeBooking = null;
      notifyListeners();
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      notifyListeners();
    }
  }

  Future<void> loadPending() async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      pendingBookings = await _bookingService.pending();
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadHistory({String? status}) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      historyBookings = await _bookingService.history(status: status);
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  /// Returns the raw create-response data on success (booking_id,
  /// estimated_fare, ...) or null on failure (check [errorMessage]).
  Future<Map<String, dynamic>?> createBooking({
    required int vehicleCategoryId,
    required String pickupAddress,
    required double pickupLat,
    required double pickupLng,
    required String deliveryAddress,
    required double deliveryLat,
    required double deliveryLng,
    String? goodsDescription,
    required String paymentMode,
  }) async {
    isSubmitting = true;
    errorMessage = null;
    notifyListeners();
    try {
      final data = await _bookingService.create(
        vehicleCategoryId: vehicleCategoryId,
        pickupAddress: pickupAddress,
        pickupLat: pickupLat,
        pickupLng: pickupLng,
        deliveryAddress: deliveryAddress,
        deliveryLat: deliveryLat,
        deliveryLng: deliveryLng,
        goodsDescription: goodsDescription,
        paymentMode: paymentMode,
      );
      await refreshActiveBooking();
      return data;
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      return null;
    } finally {
      isSubmitting = false;
      notifyListeners();
    }
  }

  Future<bool> acceptBooking(int bookingId) async {
    isSubmitting = true;
    errorMessage = null;
    notifyListeners();
    try {
      await _bookingService.accept(bookingId);
      pendingBookings.removeWhere((b) => b.id == bookingId);
      await refreshActiveBooking();
      return true;
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      return false;
    } finally {
      isSubmitting = false;
      notifyListeners();
    }
  }

  Future<bool> completeBooking(int bookingId, {double? finalFare}) async {
    isSubmitting = true;
    errorMessage = null;
    notifyListeners();
    try {
      await _bookingService.complete(bookingId, finalFare: finalFare);
      activeBooking = null;
      return true;
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      return false;
    } finally {
      isSubmitting = false;
      notifyListeners();
    }
  }

  Future<bool> confirmPayment(int bookingId, {required bool success}) async {
    isSubmitting = true;
    errorMessage = null;
    notifyListeners();
    try {
      await _paymentService.updateStatus(
        bookingId: bookingId,
        paymentStatus: success ? PaymentStatus.paid : PaymentStatus.failed,
      );
      return true;
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      return false;
    } finally {
      isSubmitting = false;
      notifyListeners();
    }
  }

  Future<BookingModel?> fetchDetails(int bookingId) async {
    try {
      return await _bookingService.details(bookingId);
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      notifyListeners();
      return null;
    }
  }

  void clearError() {
    errorMessage = null;
    notifyListeners();
  }
}
