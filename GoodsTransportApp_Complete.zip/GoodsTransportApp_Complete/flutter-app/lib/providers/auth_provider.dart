import 'package:flutter/foundation.dart';
import '../core/constants.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';

enum AuthStatus { unknown, loggedOut, loggedIn }

class AuthProvider extends ChangeNotifier {
  final AuthService _authService;
  final StorageService _storage;

  AuthProvider(this._authService, this._storage);

  AuthStatus status = AuthStatus.unknown;
  UserModel? user;
  bool isLoading = false;
  String? errorMessage;

  bool get isCustomer => user?.role == UserRole.customer;
  bool get isDriver => user?.role == UserRole.driver;

  /// Called once at app startup to restore a saved session, if any.
  Future<void> restoreSession() async {
    final token = await _storage.getToken();
    final savedUser = await _storage.getUser();
    if (token != null && savedUser != null) {
      user = savedUser;
      status = AuthStatus.loggedIn;
    } else {
      status = AuthStatus.loggedOut;
    }
    notifyListeners();

    // Refresh from server in the background so stale local data
    // (e.g. admin deactivated the account) doesn't linger unnoticed.
    if (status == AuthStatus.loggedIn) {
      try {
        user = await _authService.fetchProfile();
        notifyListeners();
      } catch (_) {
        // Keep the cached profile if the refresh fails (e.g. offline);
        // authenticateRequest() on the next real action will catch a
        // truly invalid/expired token and prompt re-login then.
      }
    }
  }

  Future<bool> register({
    required String name,
    required String mobile,
    required String password,
    required String role,
    String? email,
    int? vehicleCategoryId,
    String? vehicleNumber,
    String? drivingLicense,
  }) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      user = await _authService.register(
        name: name,
        mobile: mobile,
        password: password,
        role: role,
        email: email,
        vehicleCategoryId: vehicleCategoryId,
        vehicleNumber: vehicleNumber,
        drivingLicense: drivingLicense,
      );
      status = AuthStatus.loggedIn;
      return true;
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      return false;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> login({
    required String mobile,
    required String password,
    required String role,
  }) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      user = await _authService.login(mobile: mobile, password: password, role: role);
      status = AuthStatus.loggedIn;
      return true;
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      return false;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    isLoading = true;
    notifyListeners();
    await _authService.logout();
    user = null;
    status = AuthStatus.loggedOut;
    isLoading = false;
    notifyListeners();
  }

  Future<bool> updateProfile({
    String? name,
    String? email,
    String? vehicleNumber,
    String? drivingLicense,
    bool? isAvailable,
    String? currentPassword,
    String? newPassword,
  }) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      user = await _authService.updateProfile(
        name: name,
        email: email,
        vehicleNumber: vehicleNumber,
        drivingLicense: drivingLicense,
        isAvailable: isAvailable,
        currentPassword: currentPassword,
        newPassword: newPassword,
      );
      return true;
    } catch (e) {
      errorMessage = e.toString().replaceFirst('Exception: ', '');
      return false;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  void clearError() {
    errorMessage = null;
    notifyListeners();
  }
}
