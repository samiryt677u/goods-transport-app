import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/constants.dart';
import 'core/theme.dart';
import 'providers/auth_provider.dart';
import 'providers/booking_provider.dart';
import 'screens/splash_screen.dart';
import 'services/api_client.dart';
import 'services/auth_service.dart';
import 'services/booking_service.dart';
import 'services/payment_service.dart';
import 'services/storage_service.dart';
import 'services/vehicle_category_service.dart';

void main() {
  runApp(const GoodsTransportApp());
}

class GoodsTransportApp extends StatelessWidget {
  const GoodsTransportApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Simple manual dependency wiring — no DI package needed for an
    // app this size. Each service is a thin, stateless wrapper, so
    // constructing them here once and sharing via Provider is enough.
    final storageService = StorageService();
    final apiClient = ApiClient(storageService);
    final authService = AuthService(apiClient, storageService);
    final categoryService = VehicleCategoryService(apiClient);
    final bookingService = BookingService(apiClient);
    final paymentService = PaymentService(apiClient);

    return MultiProvider(
      providers: [
        ChangeNotifierProvider<AuthProvider>(
          create: (_) => AuthProvider(authService, storageService)..restoreSession(),
        ),
        ChangeNotifierProvider<BookingProvider>(
          create: (_) => BookingProvider(bookingService, categoryService, paymentService),
        ),
      ],
      child: MaterialApp(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        home: const SplashScreen(),
      ),
    );
  }
}
