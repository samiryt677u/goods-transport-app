import '../core/constants.dart';
import '../models/user_model.dart';
import 'api_client.dart';
import 'storage_service.dart';

class AuthService {
  final ApiClient _api;
  final StorageService _storage;
  AuthService(this._api, this._storage);

  Future<UserModel> register({
    required String name,
    required String mobile,
    required String password,
    required String role,
    String? email,
    int? vehicleCategoryId,
    String? vehicleNumber,
    String? drivingLicense,
  }) async {
    final body = <String, dynamic>{
      'name': name,
      'mobile': mobile,
      'password': password,
      'role': role,
      if (email != null && email.isNotEmpty) 'email': email,
      if (role == UserRole.driver) ...{
        'vehicle_category_id': vehicleCategoryId,
        'vehicle_number': vehicleNumber,
        if (drivingLicense != null && drivingLicense.isNotEmpty)
          'driving_license': drivingLicense,
      },
    };

    final response = await _api.post(ApiConstants.register, body: body, auth: false);
    final data = response['data'] as Map<String, dynamic>;
    final token = data['token'] as String;
    final user = UserModel.fromJson(data['user'] as Map<String, dynamic>);

    await _storage.saveSession(token, user);
    return user;
  }

  Future<UserModel> login({
    required String mobile,
    required String password,
    required String role,
  }) async {
    final response = await _api.post(
      ApiConstants.login,
      body: {'mobile': mobile, 'password': password, 'role': role},
      auth: false,
    );
    final data = response['data'] as Map<String, dynamic>;
    final token = data['token'] as String;
    final user = UserModel.fromJson(data['user'] as Map<String, dynamic>);

    await _storage.saveSession(token, user);
    return user;
  }

  Future<void> logout() async {
    try {
      await _api.post(ApiConstants.logout);
    } catch (_) {
      // Even if the network call fails, we still clear the local
      // session below — logout must always succeed from the user's
      // point of view.
    }
    await _storage.clearSession();
  }

  Future<UserModel> fetchProfile() async {
    final response = await _api.get(ApiConstants.profileGet);
    return UserModel.fromJson(response['data'] as Map<String, dynamic>);
  }

  Future<UserModel> updateProfile({
    String? name,
    String? email,
    String? vehicleNumber,
    String? drivingLicense,
    bool? isAvailable,
    String? currentPassword,
    String? newPassword,
  }) async {
    final body = <String, dynamic>{
      if (name != null) 'name': name,
      if (email != null) 'email': email,
      if (vehicleNumber != null) 'vehicle_number': vehicleNumber,
      if (drivingLicense != null) 'driving_license': drivingLicense,
      if (isAvailable != null) 'is_available': isAvailable,
      if (currentPassword != null) 'current_password': currentPassword,
      if (newPassword != null) 'new_password': newPassword,
    };
    final response = await _api.post(ApiConstants.profileUpdate, body: body);
    final user = UserModel.fromJson(response['data'] as Map<String, dynamic>);
    await _storage.updateStoredUser(user);
    return user;
  }
}
