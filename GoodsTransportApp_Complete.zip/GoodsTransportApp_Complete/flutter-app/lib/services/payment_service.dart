import '../core/constants.dart';
import 'api_client.dart';

class PaymentService {
  final ApiClient _api;
  PaymentService(this._api);

  Future<void> updateStatus({
    required int bookingId,
    required String paymentStatus, // 'paid' | 'failed'
    String? transactionId,
  }) async {
    await _api.post(ApiConstants.paymentUpdate, body: {
      'booking_id': bookingId,
      'payment_status': paymentStatus,
      if (transactionId != null) 'transaction_id': transactionId,
    });
  }
}
