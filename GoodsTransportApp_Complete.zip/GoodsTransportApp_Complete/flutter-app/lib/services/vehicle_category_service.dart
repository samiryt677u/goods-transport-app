import '../core/constants.dart';
import '../models/vehicle_category_model.dart';
import 'api_client.dart';

class VehicleCategoryService {
  final ApiClient _api;
  VehicleCategoryService(this._api);

  Future<List<VehicleCategoryModel>> list() async {
    // Public endpoint — usable even before login (e.g. driver signup form).
    final response = await _api.get(ApiConstants.vehicleCategories, auth: false);
    final data = response['data'] as List<dynamic>;
    return data
        .map((e) => VehicleCategoryModel.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}
