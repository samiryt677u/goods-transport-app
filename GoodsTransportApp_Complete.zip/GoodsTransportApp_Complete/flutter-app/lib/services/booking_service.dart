import '../core/constants.dart';
import '../models/booking_model.dart';
import 'api_client.dart';

class BookingService {
  final ApiClient _api;
  BookingService(this._api);

  /// Returns the raw response `data` map from create.php (booking_id,
  /// booking_code, estimated_fare, etc.) — the caller decides whether to
  /// immediately follow up with a details.php call for the full model.
  Future<Map<String, dynamic>> create({
    required int vehicleCategoryId,
    required String pickupAddress,
    required double pickupLat,
    required double pickupLng,
    required String deliveryAddress,
    required double deliveryLat,
    required double deliveryLng,
    String? goodsDescription,
    required String paymentMode,
  }) async {
    final response = await _api.post(ApiConstants.bookingCreate, body: {
      'vehicle_category_id': vehicleCategoryId,
      'pickup_address': pickupAddress,
      'pickup_lat': pickupLat,
      'pickup_lng': pickupLng,
      'delivery_address': deliveryAddress,
      'delivery_lat': deliveryLat,
      'delivery_lng': deliveryLng,
      if (goodsDescription != null && goodsDescription.isNotEmpty)
        'goods_description': goodsDescription,
      'payment_mode': paymentMode,
    });
    return response['data'] as Map<String, dynamic>;
  }

  Future<List<BookingModel>> pending() async {
    final response = await _api.get(ApiConstants.bookingPending);
    final data = response['data'] as List<dynamic>;
    return data.map((e) => BookingModel.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<BookingModel> accept(int bookingId) async {
    final response = await _api.post(
      ApiConstants.bookingAccept,
      body: {'booking_id': bookingId},
    );
    return BookingModel.fromJson(response['data'] as Map<String, dynamic>);
  }

  Future<Map<String, dynamic>> complete(int bookingId, {double? finalFare}) async {
    final response = await _api.post(ApiConstants.bookingComplete, body: {
      'booking_id': bookingId,
      if (finalFare != null) 'final_fare': finalFare,
    });
    return response['data'] as Map<String, dynamic>;
  }

  Future<List<BookingModel>> history({String? status}) async {
    var url = ApiConstants.bookingHistory;
    if (status != null) {
      url = '$url?status=$status';
    }
    final response = await _api.get(url);
    final data = response['data'] as List<dynamic>;
    return data.map((e) => BookingModel.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<BookingModel> details(int bookingId) async {
    final response =
        await _api.get('${ApiConstants.bookingDetails}?booking_id=$bookingId');
    return BookingModel.fromJson(response['data'] as Map<String, dynamic>);
  }
}
