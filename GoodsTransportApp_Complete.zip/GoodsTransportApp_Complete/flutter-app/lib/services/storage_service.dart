import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants.dart';
import '../models/user_model.dart';

/// Wraps SharedPreferences so the rest of the app never touches the
/// storage API directly. Holds the JWT token and the last-known user
/// profile so the app can restore a session on cold start without an
/// extra network round trip.
class StorageService {
  Future<void> saveSession(String token, UserModel user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.prefKeyToken, token);
    await prefs.setString(AppConstants.prefKeyUser, jsonEncode(user.toJson()));
    await prefs.setString(AppConstants.prefKeyRole, user.role);
  }

  Future<void> updateStoredUser(UserModel user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.prefKeyUser, jsonEncode(user.toJson()));
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(AppConstants.prefKeyToken);
  }

  Future<UserModel?> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(AppConstants.prefKeyUser);
    if (raw == null) return null;
    try {
      return UserModel.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<String?> getRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(AppConstants.prefKeyRole);
  }

  Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(AppConstants.prefKeyToken);
    await prefs.remove(AppConstants.prefKeyUser);
    await prefs.remove(AppConstants.prefKeyRole);
  }
}
