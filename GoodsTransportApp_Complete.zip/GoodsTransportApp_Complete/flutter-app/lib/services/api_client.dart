import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../core/constants.dart';
import 'storage_service.dart';

/// Thrown for any non-2xx response or network failure. The [message] is
/// already the human-readable string from the API's `message` field
/// (or a sensible fallback), so screens can show it directly.
class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, {this.statusCode});

  @override
  String toString() => message;
}

class ApiClient {
  final StorageService _storage;
  ApiClient(this._storage);

  Future<Map<String, String>> _headers({bool auth = true}) async {
    final headers = {'Content-Type': 'application/json'};
    if (auth) {
      final token = await _storage.getToken();
      if (token != null) {
        headers['Authorization'] = 'Bearer $token';
      }
    }
    return headers;
  }

  Map<String, dynamic> _decode(http.Response response) {
    Map<String, dynamic> body;
    try {
      body = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw ApiException(
        'Unexpected server response (HTTP ${response.statusCode})',
        statusCode: response.statusCode,
      );
    }

    final ok = body['status'] == true;
    if (!ok) {
      throw ApiException(
        body['message']?.toString() ?? 'Something went wrong',
        statusCode: response.statusCode,
      );
    }
    return body;
  }

  Future<Map<String, dynamic>> get(String url, {bool auth = true}) async {
    try {
      final response = await http
          .get(Uri.parse(url), headers: await _headers(auth: auth))
          .timeout(ApiConstants.requestTimeout);
      return _decode(response);
    } on ApiException {
      rethrow;
    } on SocketException {
      throw ApiException('No internet connection. Please check your network.');
    } catch (e) {
      throw ApiException('Could not reach the server. Please try again.');
    }
  }

  Future<Map<String, dynamic>> post(
    String url, {
    Map<String, dynamic>? body,
    bool auth = true,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse(url),
            headers: await _headers(auth: auth),
            body: jsonEncode(body ?? {}),
          )
          .timeout(ApiConstants.requestTimeout);
      return _decode(response);
    } on ApiException {
      rethrow;
    } on SocketException {
      throw ApiException('No internet connection. Please check your network.');
    } catch (e) {
      throw ApiException('Could not reach the server. Please try again.');
    }
  }
}
