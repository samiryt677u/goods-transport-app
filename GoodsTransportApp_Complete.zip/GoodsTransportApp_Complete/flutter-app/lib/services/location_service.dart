import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';

class LocationResult {
  final double lat;
  final double lng;
  final String address;
  LocationResult({required this.lat, required this.lng, required this.address});
}

class LocationService {
  /// Requests permission and returns the device's current position.
  /// Throws a plain [Exception] with a user-facing message on failure —
  /// callers show it directly rather than a stack trace.
  Future<Position> getCurrentPosition() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception('Please turn on location services to continue');
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception('Location permission is required to pick a spot on the map');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw Exception(
        'Location permission is permanently denied. Please enable it from app settings.',
      );
    }

    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
    );
  }

  /// Converts lat/lng into a human-readable address. Falls back to raw
  /// coordinates if the device has no reverse-geocoding data available
  /// (e.g. no Google Play Services on some Android builds).
  Future<String> reverseGeocode(double lat, double lng) async {
    try {
      final placemarks = await placemarkFromCoordinates(lat, lng);
      if (placemarks.isEmpty) {
        return '${lat.toStringAsFixed(5)}, ${lng.toStringAsFixed(5)}';
      }
      final p = placemarks.first;
      final parts = [
        p.name,
        p.subLocality,
        p.locality,
        p.administrativeArea,
      ].where((e) => e != null && e.trim().isNotEmpty).toSet().toList();
      return parts.isEmpty
          ? '${lat.toStringAsFixed(5)}, ${lng.toStringAsFixed(5)}'
          : parts.join(', ');
    } catch (_) {
      return '${lat.toStringAsFixed(5)}, ${lng.toStringAsFixed(5)}';
    }
  }

  /// Forward geocodes a free-text search query (used by the search box
  /// on the location picker screen) into a coordinate + resolved address.
  Future<LocationResult?> searchAddress(String query) async {
    try {
      final locations = await locationFromAddress(query);
      if (locations.isEmpty) return null;
      final loc = locations.first;
      final address = await reverseGeocode(loc.latitude, loc.longitude);
      return LocationResult(lat: loc.latitude, lng: loc.longitude, address: address);
    } catch (_) {
      return null;
    }
  }
}
