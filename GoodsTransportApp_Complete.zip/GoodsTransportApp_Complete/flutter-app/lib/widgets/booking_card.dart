import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../models/booking_model.dart';
import 'status_badge.dart';

class BookingCard extends StatelessWidget {
  final BookingModel booking;
  final VoidCallback? onTap;
  final Widget? trailingAction;

  const BookingCard({
    super.key,
    required this.booking,
    this.onTap,
    this.trailingAction,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    booking.bookingCode,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                  StatusBadge(status: booking.status),
                ],
              ),
              const SizedBox(height: 10),
              _LocationRow(icon: Icons.circle, color: AppColors.completed, text: booking.pickupAddress),
              const Padding(
                padding: EdgeInsets.only(left: 5),
                child: SizedBox(
                  height: 14,
                  child: VerticalDivider(thickness: 1.5, width: 1.5),
                ),
              ),
              _LocationRow(icon: Icons.location_on, color: AppColors.cancelled, text: booking.deliveryAddress),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      if (booking.vehicleCategoryName != null) ...[
                        Icon(Icons.local_shipping_outlined, size: 16, color: AppColors.textSecondary),
                        const SizedBox(width: 4),
                        Text(
                          booking.vehicleCategoryName!,
                          style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
                        ),
                        const SizedBox(width: 12),
                      ],
                      Icon(Icons.route_outlined, size: 16, color: AppColors.textSecondary),
                      const SizedBox(width: 4),
                      Text(
                        '${booking.distanceKm.toStringAsFixed(1)} km',
                        style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
                      ),
                    ],
                  ),
                  Text(
                    '₹${booking.displayFare.toStringAsFixed(0)}',
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                  ),
                ],
              ),
              if (trailingAction != null) ...[
                const SizedBox(height: 10),
                trailingAction!,
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _LocationRow extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String text;
  const _LocationRow({required this.icon, required this.color, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 3),
          child: Icon(icon, size: 10, color: color),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13.5, color: AppColors.textPrimary),
          ),
        ),
      ],
    );
  }
}
